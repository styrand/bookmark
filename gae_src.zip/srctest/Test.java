import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.lang3.StringEscapeUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.xml.sax.SAXException;

import de.l3s.boilerpipe.BoilerpipeExtractor;
import de.l3s.boilerpipe.BoilerpipeProcessingException;
import de.l3s.boilerpipe.extractors.ArticleExtractor;
import de.l3s.boilerpipe.extractors.CommonExtractors;
import de.l3s.boilerpipe.sax.HTMLHighlighter;
import styrand.server.GReaderRssServlet;
import styrand.server.RSSUtils;


public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.setProperty("java.net.useSystemProxies", "true");
		
//		String s = "http://lequipe.appli-android.airweb.fr/serv/EFRAndroidAp?compet=FRD1&com=jourdefandfrXHTD08&sport=1";
		
		try {
			Document doc = Jsoup.parse(new File("test.html"), "UTF-8");
			Elements aa = doc.getElementsByTag("a");
			for(int i=0;i<aa.size();i++) {
				Element a = aa.get(i);
				Elements e = a.getElementsByClass("btstrn");
				System.err.println(a.attr("href")+"-"+e.text());
//				Elements ee = element.getElementsByClass("textM");
//				Elements a = element.getElementsByTag("a");
//				System.err.println(a.get(0).attr("href"));
//				for(int j=0;j<ee.size();j++) {
//					Element eee = ee.get(j);
//				    System.err.println(eee.text());
//				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
