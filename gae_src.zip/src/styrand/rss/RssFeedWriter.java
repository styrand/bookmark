package styrand.rss;

import java.io.OutputStream;
import java.io.OutputStreamWriter;

import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartDocument;
import javax.xml.stream.events.StartElement;

public class RssFeedWriter {

	private Rss rss;

	public RssFeedWriter(Rss rssfeed) {
		this.rss = rssfeed;
	}

	public void write(OutputStream os) throws Exception {

		// Create a XMLOutputFactory
		XMLOutputFactory outputFactory = XMLOutputFactory.newInstance();

		// Create XMLEventWriter
		XMLEventWriter eventWriter = outputFactory
				.createXMLEventWriter(new OutputStreamWriter(os,"UTF-8"));

		// Create a EventFactory

		XMLEventFactory eventFactory = XMLEventFactory.newInstance();
//		XMLEvent end = eventFactory.createDTD("\n");

		// Create and write Start Tag

		StartDocument startDocument = eventFactory.createStartDocument();

		eventWriter.add(startDocument);

		// Create open tag
//		eventWriter.add(end);

		StartElement rssStart = eventFactory.createStartElement("", "", "rss");
		eventWriter.add(rssStart);
		eventWriter.add(eventFactory.createAttribute("version", "2.0"));
//		eventWriter.add(end);

		eventWriter.add(eventFactory.createStartElement("", "", "channel"));
//		eventWriter.add(end);

		// Write the different nodes

		createNode(eventWriter, "title", rss.getTitle());

		createNode(eventWriter, "link", rss.getLink());

		createNode(eventWriter, "description", rss.getDescription());

		createNode(eventWriter, "language", rss.getLanguage());

		createNode(eventWriter, "copyright", rss.getCopyright());

		createNode(eventWriter, "lastBuildDate", rss.getPubDate());

		createNode(eventWriter, "pubDate", rss.getPubDate());
		
		for (Item item : rss.getItems()) {
			eventWriter.add(eventFactory.createStartElement("", "", "item"));
//			eventWriter.add(end);
			createNode(eventWriter, "title", item.getTitle());
			createNode(eventWriter, "link", item.getLink());
			createNode(eventWriter, "guid", item.getGuid());
			createNode(eventWriter, "description", item.getDescription(), true);
			createNode(eventWriter, "pubDate", item.getPubdate());
//			eventWriter.add(end);
			eventWriter.add(eventFactory.createEndElement("", "", "item"));
//			eventWriter.add(end);
		}

//		eventWriter.add(end);
		eventWriter.add(eventFactory.createEndElement("", "", "channel"));
//		eventWriter.add(end);
		eventWriter.add(eventFactory.createEndElement("", "", "rss"));

//		eventWriter.add(end);

		eventWriter.add(eventFactory.createEndDocument());

		eventWriter.close();
	}

	private void createNode(XMLEventWriter eventWriter, String name,
	String value) throws XMLStreamException {
		createNode(eventWriter, name, value, false);
	}
	private void createNode(XMLEventWriter eventWriter, String name,
	  String value, boolean cdata) throws XMLStreamException {
		XMLEventFactory eventFactory = XMLEventFactory.newInstance();
//		XMLEvent end = eventFactory.createDTD("\n");
//		XMLEvent tab = eventFactory.createDTD("\t");
		// Create Start node
		StartElement sElement = eventFactory.createStartElement("", "", name);
//		eventWriter.add(tab);
		eventWriter.add(sElement);
		if(cdata) {
			Characters characters = eventFactory.createCData(value);
			eventWriter.add(characters);			
		}
		else {
			// Create Content
			Characters characters = eventFactory.createCharacters(value);
			eventWriter.add(characters);			
		}
		// Create End node
		EndElement eElement = eventFactory.createEndElement("", "", name);
		eventWriter.add(eElement);
//		eventWriter.add(end);
	}
}