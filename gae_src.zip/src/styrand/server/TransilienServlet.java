package styrand.server;

import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.Logger;
import java.util.zip.GZIPOutputStream;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet d appel au reseau transilien
 * Parsing de l url http://www.transilien.mobi/TempReelListe.do?depart.code=LDU&arrivee.code=VFD
 * @author f0410021
 *
 */
public class TransilienServlet extends HttpServlet {
    private static final Logger LOG = Logger.getLogger(TransilienServlet.class.getName());
	
    public void init(ServletConfig config) throws ServletException {   
        super.init(config);        
        LOG.info("Initialisation de la servlet TransilienServlet ...");
    }
	
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
    	String depart = req.getParameter("depart.code");
    	if(depart == null) {
        	depart = req.getParameter("depart");    		
    	}
    	String arrivee = req.getParameter("arrivee.code");
    	if(arrivee == null) {
    		arrivee = req.getParameter("arrivee");    		
    	}
    	
		long t1 = System.currentTimeMillis();
    	RSSFeedWriter feedWriter = RSSUtils.transilien(depart, arrivee);
		long t2 = System.currentTimeMillis();
    	LOG.info("transilien in "+(t2-t1)+" ms");	    		
    	
    	if(feedWriter != null) {
				resp.setContentType("text/xml");
	            ServletOutputStream out = resp.getOutputStream();
	            feedWriter.write(out);
	    		long t3 = System.currentTimeMillis();
	        	LOG.info("write feed in "+(t3-t2)+" ms");	    		
	            out.flush();
	            out.close();
    	}
			
		} catch (Exception e) {
			LOG.severe("Exception while writing feed "+e);
		}
    }
}