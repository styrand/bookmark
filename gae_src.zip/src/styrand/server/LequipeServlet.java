package styrand.server;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import styrand.rss.Item;
import styrand.rss.Rss;
import styrand.rss.RssFeedWriter;

/**
 */
public class LequipeServlet extends HttpServlet {
    private static final Logger LOG = Logger.getLogger(LequipeServlet.class.getName());
    
    private static final Map<String, String> urlByType = new HashMap<String, String>();

    public void init(ServletConfig config) throws ServletException {   
        super.init(config);  
        urlByType.put("l1", "http://lequipe.appli-android.airweb.fr/serv/EFRAndroidAp?compet=FRD1&com=jourdefandfrXHTD08&sport=1");
        LOG.info("Initialisation de la servlet LequipeServlet ...");
    }
	
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
	    	String type = req.getParameter("type");	    	
LOG.info("Appel de lequipe avec type "+type);
	    	if(type != null) {
	    		String url = urlByType.get(type);
	    		LOG.info("Url lequipe "+url);
	    		
	    		if(url != null) {
	        	// Create the rss feed
	    		String copyright = "S Tyrand";
	    		String title = "Lequipe ";
	    		String description = "Lequipe ";
	    		String language = "fr";
	    		String link = "http://styrand-notebook.appspot.com";
	    		Calendar cal = new GregorianCalendar();
	    		cal.add(Calendar.HOUR, 1);
	    		Date creationDate = cal.getTime();
	    		String pubdate = formatDate(creationDate);
	    		Rss rss = new Rss(title, link, description, language,
	    				copyright, pubdate);
	    		
	    		String infos = extractInfos(url);

	    		// Now add one example entry
	    			Item item = new Item();
	    			item.setTitle("Lequipe ");
	    			item.setDescription(infos);
	    			item.setAuthor("S Tyrand");
	    			item.setGuid(url);
	    			item.setLink(item.getGuid());
	    			item.setPubdate(formatDate(new Date()));
	    			rss.getItems().add(item);			

	    		// Now write the file
	    		RssFeedWriter writer = new RssFeedWriter(rss);
	    		
				resp.setContentType("text/xml");
//				Iterator<String> keys = headers.keySet().iterator();
//				while(keys.hasNext()) {
//					String key = keys.next();
//					for(String s : headers.get(key)) {
//						if(resp.containsHeader(key)) {
//							resp.addHeader(key, s);																		
//						}
//						else {
//							resp.setHeader(key, s);
//						}
//					}
//				}
	            ServletOutputStream out = resp.getOutputStream();
	            
	            writer.write(out);
	            out.flush();
	            out.close();	    		
    			
    		}
    		
	    	}
		} catch (Throwable e) {
			LOG.log(Level.SEVERE, "Exception in class "+this.getClass().getName(),e);	
		}
    }
    private static String formatDate(Date date) {
		SimpleDateFormat date_format = new SimpleDateFormat(
				"EEE', 'dd' 'MMM' 'yyyy' 'HH:mm:ss' 'Z", Locale.US);
		String sdate = date_format.format(date);
		
		return sdate;
    	
    }
    private static String extractInfos(String url) throws MalformedURLException, IOException {
    	LOG.info("Extract info from url "+url);
		StringBuffer sb = new StringBuffer();
		Document doc = Jsoup.parse(new URL(url), 5000);
		Elements tables = doc.getElementsByClass("table");
    	LOG.info("Extract info tables "+tables.size());
		for(int i=0;i<tables.size();i++) {
			Element table = tables.get(i);
			Elements cells = table.getElementsByClass("textM");
	    	LOG.info("Extract info cells "+cells.size());
			Elements a = table.getElementsByTag("a");
			String href = null;
			if(a != null && a.size() > 0) {
				href = a.get(0).attr("href");
			}
			sb.append("<p style=\"padding: 0;margin: 0;\">");
			if(href != null) {
				sb.append("<a href=\"http://lequipe.appli-android.airweb.fr"+a+"\">");
			}
			for(int j=0;j<cells.size();j++) {
				Element cell = cells.get(j);
		    	LOG.info("Extract info cell "+cell.text());
				sb.append(cell.text()+" ");
			}
			if(href != null) {
				sb.append("</a>");
			}
			sb.append("</p>");
		}
		return sb.toString();
    	
    }
    
}