package styrand.server;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet d appel au reseau transilien
 * Parsing de l url http://www.transilien.mobi/TempReelListe.do?depart.code=LDU&arrivee.code=VFD
 * @author f0410021
 *
 */
public class Rss2HtmlServlet extends HttpServlet {
    private static final Logger LOG = Logger.getLogger(Rss2HtmlServlet.class.getName());

    public void init(ServletConfig config) throws ServletException {   
        super.init(config);        
        LOG.info("Initialisation de la servlet Rss2HtmlServlet ...");
    }
	
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
	    	String url = req.getParameter("url");	    	
	    	String greader = req.getParameter("greader");	    	

	    	if(url != null) {
	    		if(!url.startsWith("http://")) {
	    			url = "http://" + url;
	    		}
		    	LOG.info("url : "+url);
				long t1 = System.currentTimeMillis();
				
				String nbItems = null;;
				if(req.getSession() != null) {
					nbItems = (String)req.getSession().getAttribute("nbItems");
					if(nbItems == null) {
						nbItems = "100";
					}
				}
				
	    		List<FeedMessage> list = RSSUtils.convert2List(url, "true".equals(greader), nbItems);
				long t2 = System.currentTimeMillis();
				
	    		req.setAttribute("list", list);
	    		req.getRequestDispatcher("/rss.jsp").forward(req, resp);
				
		    	LOG.info("Rss2HtmlServlet url : "+url+" in "+(t2-t1)+" ms");	    		
	    	}
		} catch (Exception e) {
			LOG.severe("Exception while writing feed "+e);
		}
    }
}