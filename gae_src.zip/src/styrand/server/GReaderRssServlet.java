package styrand.server;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.logging.Logger;
import java.util.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * Servlet d appel au reseau transilien
 * Parsing de l url http://www.transilien.mobi/TempReelListe.do?depart.code=LDU&arrivee.code=VFD
 * @author f0410021
 *
 */
public class GReaderRssServlet extends HttpServlet {
    private static final Logger LOG = Logger.getLogger(GReaderRssServlet.class.getName());
    
    protected static final int BLOCK_SIZE = 4096;  

    public void init(ServletConfig config) throws ServletException {   
        super.init(config);        
        LOG.info("Initialisation de la servlet GReaderRssServlet ...");
    }
	
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
    		List<String> values = new ArrayList<String>();
			List<String> keys = new ArrayList<String>();
			extractRssList(keys, values);
    		LOG.info("List of rss "+keys+" "+values);
    		req.setAttribute("keys", keys);
    		req.setAttribute("values", values);
    		req.getRequestDispatcher("/greader.jsp").forward(req, resp);
//    		resp.sendRedirect("greader.jsp");
		} catch (Exception e) {
			LOG.warning("Exception while writing url "+e);
		} finally {
		}
    }
    public static void extractRssList(List<String> keys, List<String> values) {
		String token = GReaderUtils.getAuthToken("styrand@gmail.com","sty78220");
		if(token != null) {
			extractRssList("http://www.google.com/reader/api/0/subscription/list?output=xml", token, keys, values);
    		LOG.info("List of rss "+keys+" "+values);
		}
    }
    private static void extractRssList(String url, String token, List<String> keys, List<String> values) {
		try {
			long t1 = System.currentTimeMillis();
	    	Document doc = Jsoup.connect(url).header("Authorization", "GoogleLogin auth=" + token).get();
			long t2 = System.currentTimeMillis();
	    	LOG.info("parsing url : "+url+" in "+(t2-t1)+" ms");
	    	Elements e = doc.getElementsByTag("string");
			long t3 = System.currentTimeMillis();
	    	LOG.info("get item url : "+url+" in "+(t3-t2)+" ms");
	    	


			// Now add one example entry
			for(int i=0;i<e.size();i++) {
				String surl = e.get(i).text();
				if(surl.startsWith("feed/")) {
					surl = surl.trim().substring(5);
					String title = e.get(i+1).text();
					keys.add(title);
					values.add(surl);
				}
			}
			
			long t4 = System.currentTimeMillis();
	    	LOG.info("get item atts url : "+url+" in "+(t4-t3)+" ms");
		} 
		catch (Exception e) {
			e.printStackTrace();
		}  
    }
    
}