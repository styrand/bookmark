package styrand.server;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.safety.Whitelist;
import org.jsoup.select.Elements;



public class RSSUtils {
    private static final Logger LOG = Logger.getLogger(TransilienServlet.class.getName());

	private final static String TRANSILIEN_URL = "http://www.transilien.mobi/TempReelListe.do";
	private final static String TRANSILIEN_URL_1 = "?depart.code=";
	private final static String TRANSILIEN_URL_2 = "&arrivee.code=";
	
    private static RSSFeedWriter createRssFeedWriter(String entete, String surl, List<String> trains, List<String> heures, List<String> dests) {
    	// Create the rss feed
		String copyright = "S Tyrand";
		String title = entete;
		String description = entete;
		String language = "fr";
		String link = surl;
		Calendar cal = new GregorianCalendar();
		cal.add(cal.HOUR, 1);
		Date creationDate = cal.getTime();
		SimpleDateFormat date_format = new SimpleDateFormat(
				"EEE', 'dd' 'MMM' 'yyyy' 'HH:mm:ss' 'Z", Locale.US);
		String pubdate = date_format.format(creationDate);
		Feed rssFeeder = new Feed(title, link, description, language,
				copyright, pubdate);

//		FeedMessage feed1 = new FeedMessage();
//		String d1 = new SimpleDateFormat("dd/MM/yyyy-HH:mm:ss",Locale.FRANCE).format(new Date());
//		String d2 = new SimpleDateFormat("dd/MM/yyyy-HH:mm:ss").format(new Date());
//		feed1.setTitle("date france "+d1+" default "+d2);
//		feed.setDescription("Transilien");
//		feed.setAuthor("transilien");
//		feed1.setGuid(link);
//		feed1.setLink(link);
//		rssFeeder.getMessages().add(feed1);			

		// Now add one example entry
		for(int i=0;i<trains.size();i++) {
			FeedMessage feed = new FeedMessage();
			feed.setTitle(heures.get(i)+" "+dests.get(i)+" "+trains.get(i));
//			feed.setDescription("Transilien");
//			feed.setAuthor("transilien");
			feed.setGuid(entete+"-"+creationDate.getTime()+"-"+i);
			feed.setLink(link);
			feed.setPubdate(pubdate);
			rssFeeder.getMessages().add(feed);			
		}

		// Now write the file
		RSSFeedWriter writer = new RSSFeedWriter(rssFeeder);
		return writer;
    }
    public static RSSFeedWriter transilien(String depart, String arrivee) {
    	String surl = TRANSILIEN_URL;
    	
    	if(depart != null) {
    		surl = surl + TRANSILIEN_URL_1 + depart.toUpperCase(); 
    	}
    	if(arrivee != null) {
    		surl = surl + TRANSILIEN_URL_2 + arrivee.toUpperCase();     		
    	}
    	
		try {
			long t1 = System.currentTimeMillis();
	    	URL url = new URL(surl);
	    	Document doc = Jsoup.parse(url, 5000);
			long t2 = System.currentTimeMillis();
	    	LOG.info("parsing url : "+surl+" in "+(t2-t1)+" ms");
			

	    	List<String> trains = new ArrayList<String>();
	    	List<String> heures = new ArrayList<String>();
	    	List<String> dests = new ArrayList<String>();
	    	
	    	String entete = "";
	    	if(depart != null) {
	    		entete = entete + depart.toUpperCase();
	    	}
	    	if(arrivee != null) {
	    		entete = entete + "/" + arrivee.toUpperCase();
	    	}
	    	
	    	String heureDemande = doc.select("#entete").text();
	    	if(heureDemande.indexOf("Demande faite") != -1) {
	    		heureDemande = heureDemande.substring(heureDemande.indexOf("Demande faite") + 15);	
	    	}
	    	if(heureDemande.indexOf("Actualiser") != -1) {
	    		heureDemande = heureDemande.substring(0,heureDemande.indexOf("Actualiser"));	
	    	}
	    	heureDemande = heureDemande.trim();
	    	
	    	entete = entete + " " +  heureDemande;
//	    	if(entete.indexOf("Arrivée : ") != -1) {
//		      entete = entete.substring(0, entete.indexOf("Arrivée : "));	
//	    	}
	    	
			Elements eltsTrains = doc.select("#Train");
			long t3 = System.currentTimeMillis();
	    	LOG.info("get train url : "+surl+" in "+(t3-t2)+" ms");
			
			Elements eltsHeures = doc.select("#heure");
			long t4 = System.currentTimeMillis();
	    	LOG.info("get heures url : "+surl+" in "+(t4-t3)+" ms");
			Elements eltsDests = doc.select("#destination");
			long t5 = System.currentTimeMillis();
	    	LOG.info("get dests url : "+surl+" in "+(t5-t4)+" ms");
			for(int i=0;i<eltsTrains.size();i++) {
				trains.add(eltsTrains.get(i).text());
				heures.add(eltsHeures.get(i).text());
				dests.add(eltsDests.get(i).text());
			}
			
			RSSFeedWriter feedWriter = createRssFeedWriter(entete, surl, trains, heures, dests);
			long t6 = System.currentTimeMillis();
	    	LOG.info("create writer url : "+surl+" in "+(t6-t5)+" ms");
	    	
			return feedWriter;
		} catch (Exception e) {
			LOG.severe("Exception while writing feed "+e);
		}
		return null;

//        if (user != null) {
//            resp.setContentType("text/plain");
//            resp.sendRedirect("/index.jsp");
//        } else {
//            resp.sendRedirect("/index.jsp");
//        }
            	
    }
    public static RSSFeedWriter convert2Description(String url, boolean greader, String n) {
		try {
			long t1 = System.currentTimeMillis();
			URL ourl = new URL(url);

	    	Document doc = null;

			if(greader) {
				String token = GReaderUtils.getAuthToken("styrand@gmail.com","sty78220");
				url = "http://www.google.com/reader/atom/feed/"+url+"?n="+n;
		    	doc = Jsoup.connect(url).header("Authorization", "GoogleLogin auth=" + token).get();
			}
			else {
		    	doc = Jsoup.parse(ourl, 5000);				
			}
			
			long t2 = System.currentTimeMillis();
	    	LOG.info("parsing url : "+url+" in "+(t2-t1)+" ms");
	    	String itemElt = null;
	    	
	    	if(greader) {
	    		itemElt = "entry";
	    	}
	    	else {
	    		itemElt = "item";
	    	}
			Elements e = doc.getElementsByTag(itemElt);
			long t3 = System.currentTimeMillis();
	    	LOG.info("get item url : "+url+" in "+(t3-t2)+" ms");
	    	
	    	// Create the rss feed
			String entete = ourl.getHost().substring(ourl.getHost().indexOf(".")+1,ourl.getHost().lastIndexOf("."));
			if(ourl.getPath() != null) {
				entete = entete + ourl.getPath();
			}
	    	
			String copyright = "S Tyrand";
			String title = entete;
			String description = entete;
			String language = "fr";
			String link = url;
			Calendar cal = new GregorianCalendar();
			cal.add(cal.HOUR, 1);
			Date creationDate = cal.getTime();
			SimpleDateFormat date_format = new SimpleDateFormat(
					"EEE', 'dd' 'MMM' 'yyyy' 'HH:mm:ss' 'Z", Locale.US);
			String pubdate = date_format.format(creationDate);
			Feed rssFeeder = new Feed(title, link, description, language,
					copyright, pubdate);


			// Now add one example entry
			for(int i=0;i<e.size();i++) {
				Element element = e.get(i);
				FeedMessage feed = new FeedMessage();
//				Elements ee = element.getElementsByTag("guid");
				feed.setTitle(element.getElementsByTag("title").text());
				
//				String contentElt = null;
//				
//				if(greader) {
//					contentElt = "content";					
//				}
//				else {
//					contentElt = "content:encoded";
//				}
//				String s = element.getElementsByTag(contentElt).text();
//				
//				if(s == null || s.length() == 0) {
//					String descriptionElt = null;
//					if(greader) {
//						descriptionElt = "summary";
//					}
//					else {
//						descriptionElt = "description";
//					}
//					
//					s = element.getElementsByTag(descriptionElt).text();
//				}
//				s = Jsoup.clean(s, relaxedWithoutImg());
//				
//				feed.setDescription(s);
////				feed.setAuthor("transilien");
				
//				String guid = null;
//				if(greader) {
//					guid = "id";
//				}
//				else {
//					guid = "guid";
//				}
//				
//				feed.setGuid(element.getElementsByTag(guid).text());
				String slink = null;
				if(greader) {
					slink = element.getElementsByTag("link").attr("href");
				}
				else {
					slink = element.getElementsByTag("link").text();
				}
				
//				feed.setLink("http://styrand.appspot.com/boiler?url="+slink);
				feed.setLink(url);
				feed.setGuid("guid-"+i);
				feed.setDescription("description");
				feed.setAuthor("styrand");
				String pubDate = null;
				if(greader) {
					pubDate = "published";
				}
				else {
					pubDate = "pubDate";
				}
				feed.setPubdate(element.getElementsByTag(pubDate).text());
				rssFeeder.getMessages().add(feed);			
			}
			
			long t4 = System.currentTimeMillis();
	    	LOG.info("get item atts url : "+url+" in "+(t4-t3)+" ms");
			

			// Now write the file
			RSSFeedWriter writer = new RSSFeedWriter(rssFeeder);
			return writer;
		} 
		catch (Exception e) {
			e.printStackTrace();
		}  
//		finally {
//			try {
//				reader.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
    	return null;
    }
    public static List<FeedMessage> convert2List(String url, boolean greader, String nbItems) {
    	List<FeedMessage> list = new ArrayList<FeedMessage>();
    	try {
			long t1 = System.currentTimeMillis();
			URL ourl = new URL(url);

	    	Document doc = null;

			if(greader) {
				String token = GReaderUtils.getAuthToken("styrand@gmail.com","sty78220");
				url = "http://www.google.com/reader/atom/feed/"+url+"?n="+nbItems;
		    	doc = Jsoup.connect(url).header("Authorization", "GoogleLogin auth=" + token).get();
			}
			else {
		    	doc = Jsoup.parse(ourl, 5000);				
			}
			
			long t2 = System.currentTimeMillis();
	    	LOG.info("parsing url : "+url+" in "+(t2-t1)+" ms");
	    	String itemElt = null;
	    	
	    	if(greader) {
	    		itemElt = "entry";
	    	}
	    	else {
	    		itemElt = "item";
	    	}
			Elements e = doc.getElementsByTag(itemElt);
			long t3 = System.currentTimeMillis();
	    	LOG.info("get item url : "+url+" in "+(t3-t2)+" ms");
	    	
			// Now add one example entry
			for(int i=0;i<e.size();i++) {
				Element element = e.get(i);
				FeedMessage feed = new FeedMessage();
				feed.setTitle(element.getElementsByTag("title").text());
				
				String slink = null;
				if(greader) {
					slink = element.getElementsByTag("link").attr("href");
				}
				else {
					slink = element.getElementsByTag("link").get(0).text();
					LOG.info("slink : "+element.getElementsByTag("link"));
				}
				
				
				
				feed.setLink("http://styrand.appspot.com/boiler?url="+slink);
				feed.setGuid(feed.getLink());
				
				String pubDate = null;
				if(greader) {
					pubDate = "published";
				}
				else {
					pubDate = "pubDate";
				}
				feed.setPubdate(element.getElementsByTag(pubDate).text());
				list.add(feed);			
			}
			
			long t4 = System.currentTimeMillis();
	    	LOG.info("get item atts url : "+url+" in "+(t4-t3)+" ms");
			
			return list;
		} 
		catch (Exception e) {
			e.printStackTrace();
		}  
//		finally {
//			try {
//				reader.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
    	return null;
    }
   public static Whitelist relaxedWithoutImg() {
       return new Whitelist()
               .addTags(
                       "a", "b", "blockquote", "br", "caption", "cite", "code", "col",
                       "colgroup", "dd", "div", "dl", "dt", "em", "h1", "h2", "h3", "h4", "h5", "h6",
                       "i", /*"img",*/ "li", "ol", "p", "pre", "q", "small", "strike", "strong",
                       "sub", "sup", "table", "tbody", "td", "tfoot", "th", "thead", "tr", "u",
                       "ul")

               .addAttributes("a", "href", "title")
               .addAttributes("blockquote", "cite")
               .addAttributes("col", "span", "width")
               .addAttributes("colgroup", "span", "width")
               .addAttributes("img", "align", "alt", "height", "src", "title", "width")
               .addAttributes("ol", "start", "type")
               .addAttributes("q", "cite")
               .addAttributes("table", "summary", "width")
               .addAttributes("td", "abbr", "axis", "colspan", "rowspan", "width")
               .addAttributes(
                       "th", "abbr", "axis", "colspan", "rowspan", "scope",
                       "width")
               .addAttributes("ul", "type")

               .addProtocols("a", "href", "ftp", "http", "https", "mailto")
               .addProtocols("blockquote", "cite", "http", "https")
//               .addProtocols("img", "src", "http", "https")
               .addProtocols("q", "cite", "http", "https")
               ;
   }
    
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
		System.setProperty("java.net.useSystemProxies", "true");
//    	String depart = "vfd";
//    	String arrivee = "psl";
    	
//    	RSSFeedWriter feedWriter = transilien(depart, arrivee);
//    	
//		feedWriter.write(new FileOutputStream(new File("test.html")));
		List l = convert2List("http://blog.paumard.org/feed/", false, "100");
    	
		System.err.println(l);
		
//    	Document doc = Jsoup.parse(new URL("http://www.olympique-et-lyonnais.com/feed"), 5000);
//    	Elements e = doc.getElementsByTag("content:encoded");
//    	System.err.println(e);
//		URL u = new URL("http://www.olympique-et-lyonnais.com/feed");
//		String s = u.getHost().substring(u.getHost().indexOf(".")+1,u.getHost().lastIndexOf("."));
//		System.err.println(s+" "+ u.getPath());
		} catch (Exception e) {
			LOG.severe("Exception while writing feed "+e);
		}
	}

}
