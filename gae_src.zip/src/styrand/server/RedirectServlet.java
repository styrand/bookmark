package styrand.server;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Logger;
import java.util.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet d appel au reseau transilien
 * Parsing de l url http://www.transilien.mobi/TempReelListe.do?depart.code=LDU&arrivee.code=VFD
 * @author f0410021
 *
 */
public class RedirectServlet extends HttpServlet {
    private static final Logger LOG = Logger.getLogger(RedirectServlet.class.getName());
    
    protected static final int BLOCK_SIZE = 4096;  

    public void init(ServletConfig config) throws ServletException {   
        super.init(config);        
        LOG.info("Initialisation de la servlet RedirectServlet ...");
    }
	
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	BufferedInputStream is = null;
    	try {
	    	String url = req.getParameter("url");	    	
	    	if(url != null) {
	    		if(!url.startsWith("http://")) {
	    			url = "http://" + url;
	    		}
		    	LOG.info("url : "+url);
				long t1 = System.currentTimeMillis();
				HttpURLConnection connection = (HttpURLConnection)new URL(url).openConnection();
				
				Map<String, List<String>> headers = connection.getHeaderFields();
				
				InputStream inputStream = connection.getInputStream();				
				is = new BufferedInputStream(inputStream);
				long t2 = System.currentTimeMillis();
		    	LOG.info("RedirectServlet url : "+url+" in "+(t2-t1)+" ms");	    		
		        int read;
		        byte[] buffer = new byte[BLOCK_SIZE];
				resp.setContentType("text/html");
				
				Iterator<String> keys = headers.keySet().iterator();
				while(keys.hasNext()) {
					String key = keys.next();
					for(String s : headers.get(key)) {
						if(resp.containsHeader(key)) {
							resp.addHeader(key, s);																		
						}
						else {
							resp.setHeader(key, s);
						}
					}
				}
	            ServletOutputStream out = resp.getOutputStream();
		        while ((read = is.read(buffer)) > 0) {
		          out.write(buffer, 0, read);
		        }
				long t3 = System.currentTimeMillis();
		    	LOG.info("RedirectServlet url : "+url+" in "+(t3-t2)+" ms");	    		
	            out.flush();
	            out.close();
    		}
		} catch (Exception e) {
			LOG.warning("Exception while writing url "+e);
		} finally {
			if(is != null) {
				is.close();
			}
		}
    }
}