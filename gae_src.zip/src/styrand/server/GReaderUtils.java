package styrand.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.logging.Logger;

public class GReaderUtils {
    private static final Logger LOG = Logger.getLogger(RssServlet.class.getName());

    private static final String GOOGLE_CLIENT_LOGIN = "https://www.google.com/accounts/ClientLogin";

	private static final String READER = "reader";
	
	private static final String SOURCE = "Gae";
    
    private static String encode(String key, String value) throws UnsupportedEncodingException {
    	return URLEncoder.encode(key, "UTF-8") + "=" + URLEncoder.encode(value, "UTF-8");
    }
    
	public static String getAuthToken(String user, String password) {
			BufferedReader rd = null;
			OutputStreamWriter wr = null;
			try {
				// Construct data
			    String data = encode("service",READER) 
			    + "&" + encode("continue","http://www.google.com/") 
			    + "&" + encode("Email",user) 
			    + "&" + encode("Passwd",password) 
			    + "&" + encode("source",SOURCE);

			    // Send data
			    URL url = new URL(GOOGLE_CLIENT_LOGIN);
			    URLConnection conn = url.openConnection();
			    conn.setDoOutput(true);
			    wr = new OutputStreamWriter(conn.getOutputStream());
			    wr.write(data);
			    wr.flush();

			    // Get the response
			    rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			    String line;
			    String auth = null;
			    while ((line = rd.readLine()) != null) {
			    	if(line.trim().startsWith("Auth=")) {
			    		auth = line.trim().substring(5);
			    	}
			    }
				LOG.info("Retrieve auth token from google account "+auth);
			    return auth;
			} catch (IOException e) {
				LOG.info("Unable to find google auth token "+e.getMessage());
			} finally {
				if(rd != null) {
					try {
						rd.close();
					} catch (IOException e) {
					}
				}
				if(wr != null) {
					try {
						wr.close();
					} catch (IOException e) {
					}
				}
			}
		return null;
	}

}
