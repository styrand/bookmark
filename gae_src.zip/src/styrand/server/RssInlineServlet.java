package styrand.server;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet d appel au reseau transilien
 * Parsing de l url http://www.transilien.mobi/TempReelListe.do?depart.code=LDU&arrivee.code=VFD
 * @author f0410021
 *
 */
public class RssInlineServlet extends HttpServlet {
    private static final Logger LOG = Logger.getLogger(RssInlineServlet.class.getName());

    public void init(ServletConfig config) throws ServletException {   
        super.init(config);        
        LOG.info("Initialisation de la servlet RssServlet ...");
    }
	
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
	    	String url = req.getParameter("url");	    	
	    	String greader = req.getParameter("greader");	    	

	    	if(url != null) {
	    		if(!url.startsWith("http://")) {
	    			url = "http://" + url;
	    		}
		    	LOG.info("url : "+url);
				long t1 = System.currentTimeMillis();
				
				String n = null;;
				if(req.getSession() != null) {
					n = (String)req.getSession().getAttribute("n");
					if(n == null) {
						n = "100";
					}
				}
				
	    		List<FeedMessage> feeds = RSSUtils.convert2List(url, "true".equals(greader), n);
				long t2 = System.currentTimeMillis();
		    	LOG.info("RSSUtils.convert2Description url : "+url+" in "+(t2-t1)+" ms");	    
//		    	URL ourl = new URL(url);
//				HttpURLConnection connection = (HttpURLConnection)ourl.openConnection();
				
//				Map<String, List<String>> headers = connection.getHeaderFields();
				
		    	LOG.info("RedirectServlet url : "+url+" in "+(t2-t1)+" ms");	    		
//				resp.setContentType("text/html");
//				
//				Iterator<String> keys = headers.keySet().iterator();
//				while(keys.hasNext()) {
//					String key = keys.next();
//					for(String s : headers.get(key)) {
//						if(resp.containsHeader(key)) {
//							resp.addHeader(key, s);																		
//						}
//						else {
//							resp.setHeader(key, s);
//						}
//					}
//				}
		    	
//					resp.setContentType("text/xml");
					
		    		req.setAttribute("title", "boiler "+url);
		    		req.setAttribute("link", url);
		    		req.setAttribute("items", feeds);
		    		req.getRequestDispatcher("/rssinline.jsp").forward(req, resp);
					
	    	}
		} catch (Exception e) {
			LOG.severe("Exception while writing feed "+e);
		}
    }
}