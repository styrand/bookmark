package styrand.server;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringEscapeUtils;

import de.l3s.boilerpipe.BoilerpipeExtractor;
import de.l3s.boilerpipe.extractors.ArticleExtractor;
import de.l3s.boilerpipe.extractors.CommonExtractors;
import de.l3s.boilerpipe.sax.HTMLHighlighter;

/**
 * @author f0410021
 *
 */
public class BoilerServlet extends HttpServlet {
    private static final Logger LOG = Logger.getLogger(BoilerServlet.class.getName());

    public void init(ServletConfig config) throws ServletException {   
        super.init(config);        
        LOG.info("Initialisation de la servlet BoilerServlet ...");
    }
	
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
	    	String url = req.getParameter("url");	    	

	    	if(url != null) {
	    		if(!url.startsWith("http://")) {
	    			url = "http://" + url;
	    		}
		    	LOG.info("url : "+url);
				long t1 = System.currentTimeMillis();
//				HttpURLConnection connection = (HttpURLConnection)new URL(url).openConnection();
//				
//				Map<String, List<String>> headers = connection.getHeaderFields();
				
	    		String content = offlineReading(url);
				long t2 = System.currentTimeMillis();
		    	LOG.info("BoilerServlet.process url : "+url+" in "+(t2-t1)+" ms");	 
		    	
		    	req.setAttribute("url", url);
		    	req.setAttribute("content", content);
		    	
	    		req.getRequestDispatcher("/boiler.jsp").forward(req, resp);
		    	
//	    		if(content != null) {
//					resp.setContentType("text/html");
//					Iterator<String> keys = headers.keySet().iterator();
//					while(keys.hasNext()) {
//						String key = keys.next();
//						for(String s : headers.get(key)) {
//							if(resp.containsHeader(key)) {
//								resp.addHeader(key, s);																		
//							}
//							else {
//								resp.setHeader(key, s);
//							}
//						}
//					}
//		            ServletOutputStream os = resp.getOutputStream();
//				    os.write(("<base href=\"" + url + "\" >").getBytes("UTF-8"));
//				    os.write("<meta http-equiv=\"Content-Type\" content=\"text-html; charset=utf-8\" />");
//				    os.write(content.getBytes("UTF-8"));
//				    os.flush();
//				    os.close();
		            
		            
//		            PrintWriter out = null;
//		  		    out = new PrintWriter(os);
//				    out.println("<base href=\"" + url + "\" >");
//				    out.println("<meta http-equiv=\"Content-Type\" content=\"text-html; charset=utf-8\" />");
//				    out.println(content);
					long t3 = System.currentTimeMillis();
			    	LOG.info("BoilerServlet.write url : "+url+" in "+(t3-t2)+" ms");	    		
//		            out.flush();
//		            out.close();
	    		}
//	    	}
		} catch (Exception e) {
			LOG.severe("Exception while writing feed "+e);
		}
    }
    private String offlineReading(String url) {
    	try {
			String text = ArticleExtractor.INSTANCE.getText(new URL("http://blog.paumard.org/2012/02/06/devoxx-france-2012-carnet-de-route-1/?utm_source=rss&utm_medium=rss&utm_campaign=devoxx-france-2012-carnet-de-route-1"));
//			text = text.replace('’', '\'');
			text = StringEscapeUtils.escapeHtml3(text);
	    	return text;
	    }
	    catch(Throwable e) {
			LOG.severe("Exception while writing url "+url+" "+e);
	    }
	    return null;
    }
//    private String offlineReading(String url) {
//	    try {
//	      LOG.info("offlineReading "+url+" ...");
//		  final BoilerpipeExtractor extractor = CommonExtractors.ARTICLE_EXTRACTOR;
//          final HTMLHighlighter hh = HTMLHighlighter.newExtractingInstance();
//	      hh.setExtraStyleSheet("");
//
//		  String s = hh.process(new URL(url), extractor);
//		  return s;
//	    }
//	    catch(Throwable e) {
//			LOG.severe("Exception while writing url "+url+" "+e);
//	    }
//	    return null;
//  }
}