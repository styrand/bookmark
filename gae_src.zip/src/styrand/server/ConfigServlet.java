package styrand.server;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author f0410021
 *
 */
public class ConfigServlet extends HttpServlet {
    private static final Logger LOG = Logger.getLogger(ConfigServlet.class.getName());

    public void init(ServletConfig config) throws ServletException {   
        super.init(config);        
        LOG.info("Initialisation de la servlet BoilerServlet ...");
    }
	
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
	    	String nbItems = req.getParameter("nbItems");	    	

	    	if(nbItems != null) {
		    	LOG.info("maj session nbItems : "+nbItems);
		    	req.getSession(true).setAttribute("nbItems", nbItems);
	    	}
	    	resp.sendRedirect("/index.html");
    }    
}