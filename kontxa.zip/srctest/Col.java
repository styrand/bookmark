
public class Col {
  String name;
  String key;
  int r;
  int g;
  int b;
}
