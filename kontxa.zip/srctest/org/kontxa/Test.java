package org.kontxa;

import java.util.ArrayList;
import java.util.List;

public class Test {

    public static List<String> getParams(String req) {
    	System.err.println(req);
    	String[] s = req.split("/");
    	if(s != null && s.length > 0) {
    		List<String> a = new ArrayList<String>();
    		for(String ss : s) {
    			ss = ss.trim();
    			if(ss.length() > 0) {
    				a.add(ss);
    			}
    		}
    		return a;
    	}
    	return null;
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.err.println(getParams("/12/1234"));
	}

}
