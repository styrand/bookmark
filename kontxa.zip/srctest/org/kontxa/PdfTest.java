package org.kontxa;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.html.simpleparser.HTMLWorker;
import com.itextpdf.text.html.simpleparser.StyleSheet;
import com.itextpdf.text.pdf.PdfWriter;

public class PdfTest {

    /** The StyleSheet. */
    protected StyleSheet styles = null;

    /**
     * Creates a list with movies in HTML and PDF simultaneously.
     * @param html a path to the resulting HTML file
     * @param pdf a path to the resulting PDF file
     * @throws SQLException
     * @throws IOException
     * @throws DocumentException
     */
    public void createPdf(String pdf) throws IOException, DocumentException {
        HashMap<String,Object> providers = new HashMap<String, Object>();
//        providers.put(HTMLWorker.FONT_PROVIDER, new MyFontFactory());
//        providers.put(HTMLWorker.IMG_PROVIDER, new MyImageFactory());
//        providers.put(HTMLWorker.LINK_PROVIDER, new MyLinkFactory());
        
        styles = new StyleSheet();
        styles.loadTagStyle("h1", "font-family", "Times New Roman");
        
//        // step 1
//        CSSResolver cssResolver = XMLWorkerHelper.getInstance().getDefaultCssResolver(true);
//        try {
//        	cssResolver.clear();
//			cssResolver.addCssFile("pdf.css", true);
//		} catch (CssResolverException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//        FontFactory.registerDirectories();
        Document document = new Document();
        // step 2
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(pdf));
        // step 3
        document.open();
        // step 4
        List<Note> notes = new ArrayList<Note>();
        Note note1 = new Note();
        String ls = System.getProperty("line.separator");
        note1.setText("toto "+ls+"==============="+ls+"tata"+ls+"--------------------"+ls+" titi "+ls+" tutu http://www.liberation.fr sdfqsqqsd");
		notes.add(note1);
        Note note2 = new Note();
        note2.setText("toto2 "+ls+" tata2 "+ls+" titi2 "+ls+" tutu2");
		notes.add(note2);
        for (Note note : notes) {
            // create the snippet
            String snippet = note.formatHtml();
            System.err.println(snippet);
//            XMLWorkerHelper.getInstance().parseXHtml(writer, document, new ByteArrayInputStream(snippet.getBytes()), new FileInputStream(new File("pdf.css")));
            
            // use the snippet for the PDF document
            List<Element> objects = HTMLWorker.parseToList(new StringReader(snippet), styles, providers);
            for (Element element : objects) {
                document.add(element);            	
            }
        	document.newPage();
        }
        // step 5
        document.close();
    }
    

//    /**
//     * Set some extra properties.
//     * @param providers the properties map
//     */
//    public void setProviders(HashMap<String, Object> providers) {
//        this.providers = providers;
//    }

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
		  new PdfTest().createPdf("test.pdf");
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}

}
