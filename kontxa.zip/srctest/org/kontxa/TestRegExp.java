package org.kontxa;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestRegExp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		String s = "calamar : http://www.cuisineaz.com/recettes/calamars-sautes-a-l-ail-et-au-persil-780.aspx ; tototottototototo frites : ; https://www.linternaute.com/femmes/cuisine/magazine/pratique/0510frites.shtml ; rtpoirpipzi ttttt : ; www.linternaute.com/femmes/cuisine/magazine/pratique/0510frites.shtml ; ttttttttttttttttt";
		String s = "calamar : <@http://www.cuisineaz.com/recettes/calamars-sautes-a-l-ail-et-au-persil-780.aspx ; tototottototototo frites : @>; https://www.linternaute.com/femmes/cuisine/magazine/pratique/0510frites.shtml ; rtpoirpipzi ttttt : ; www.linternaute.com/femmes/cuisine/magazine/pratique/0510frites.shtml ; ttttttttttttttttt";
		Pattern p = Pattern.compile("<@(.*)@>");
		Matcher m = p.matcher(s);
		Map<String, String> replacements = new HashMap<String, String>();
		while(m.find()) {
		   String srcReplace = m.group(0);
		   String toReplace = m.group(1);
		   toReplace = toReplace.trim();
		   String replaceBy = "<a href=\"https://maps.google.com/maps?q="+toReplace.replace(' ','+')+"\">"+toReplace+"</a>";
		   replacements.put(srcReplace, replaceBy);
		}
		Iterator<String> it = replacements.keySet().iterator();
		while(it.hasNext()) {
			String toReplace = it.next();
			 String replaceBy = replacements.get(toReplace);
			s = s.replace(toReplace, replaceBy);
		}
		
		System.err.println(s);
//		https://maps.google.com/maps?q=107+rue+du+fg+st+denis+75010+paris
	}

}
