package org.kontxa;

public class TestReplace {

	public static String formatSearch(String text, String search) {
		
		String formatTitle = "title";
		
		int i = text.indexOf(search);
		
		int begin = i - 50;
		
		if(begin < 0) begin = 0;
		
		int end = i + 50;
		if(end > text.length()) end = text.length();
		
		String fmtSearch = text.substring(begin, end); 
		
		fmtSearch = fmtSearch.replace(search, "<span style=\"background-color:yellow;\">"+search+"</span>");
		
		return formatTitle + " [ "+fmtSearch+" ]";
	}	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.err.println(formatSearch("true false", "true"));
	}

}
