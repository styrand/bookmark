package org.kontxa;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class MockService implements Service {
	
  private static List<Note> notes = new ArrayList<Note>();
	
  public Note createNote(String text, String type, Long categoryId) {
	  Note note = new Note();
	  note.setModificationDate(new Date());
	  note.setCreationDate(new Date());	  
	  note.setText(text);
	  note.setType(type);
	  
	  note.setOrder(notes.size());
	  note.setCategoryId(categoryId);

	  note.setId(new Long(note.getOrder()));
	  
	  notes.add(note);
	  return note;
  }
  public Note update(Note note) {
	  note.setModificationDate(new Date());
	  return note;
  }
  
  public List<Note> list() {
	  List<Note> sNotes = new ArrayList<Note>();

	  for(Note note : notes) {
		  sNotes.add(note);
	  }
	  return sNotes;
  }
  
  public Note read(long id) {
	  for(Note note : notes) {
		  if(note.getId() == id) {
			  return note;
		  }
	  }
	  return null;
  }
  public Note delete(long id) {
	  Note note = read(id);
	  return note;
  }
  public Note truncate(long id) {
	  Note note = read(id);
	  notes.remove(note);
	  return note;
  }
  public Note restore(long id) {
	  Note note = read(id);
	  return note;
  }
  public void swap(long id, long id2) {
	  for(int i=0;i<notes.size();i++) {
		  Note n = notes.get(i);
		  if(n.getId() == id) {
			  Collections.swap(notes, i, i-1);
			  break;
		  }
	  }
  }
  public List<Note> findByTags(String... tags) {
	  List<Note> sNotes = new ArrayList<Note>();

	  for(Note note : notes) {
		  for(String tag : tags) {
			  if(note.getTags().contains(tag)) {
				  sNotes.add(note);
				  break;
			  }			  
		  }
	  }
	  return sNotes;
  }
  public List<Note> findByText(String... text) {
	  List<Note> sNotes = new ArrayList<Note>();

	  for(Note note : notes) {
		  for(String t : text) {
			  if(note.getText().contains(t)) {
				  sNotes.add(note);
				  break;
			  }			  
		  }
	  }
	  return sNotes;
  }
public void clean() {
}
public void reindex() {
}
@Override
public Options readOptions() {
	return new Options();
}
@Override
public Options update(Options options) {
	return options;
}
@Override
public List<Note> list(List<String> ids) {
	return list();
}
@Override
public List<Category> listCategories() {
	List<Category> categories = new ArrayList<Category>();
	return categories;
}
@Override
public Category update(Category category) {
	return category;
}
@Override
public Category readCategory(long id) {
	return new Category();
}
@Override
public Category createCategory(String title, String color) {
	return new Category();
}
@Override
public List<Note> listByCategories(List<Long> categoryIds) {
	return list();
}
@Override
public Category getTrash() {
	// TODO Auto-generated method stub
	return null;
}

}
