import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;


public class TestJSoup {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Document doc = Jsoup.parseBodyFragment("<div class=\"note_text\"><h1 id=\"code-promo-oxybul\">Code promo Oxybul</h1><p>OFFWE30</p></div>");
		Element body = doc.body().parent();
		String stext = body.text();
		System.err.println(stext);
	}

}
