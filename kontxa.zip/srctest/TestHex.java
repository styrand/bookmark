
public class TestHex {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s = "FFE4E1";
		int i = Integer.parseInt(s, 16);
		System.err.println(i);
	}

}
