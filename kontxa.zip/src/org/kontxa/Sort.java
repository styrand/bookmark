package org.kontxa;

import java.io.Serializable;

import com.google.appengine.api.datastore.Query.SortDirection;

public class Sort implements Serializable {
  private String propertyName;
  
  private SortDirection sortDirection;

public Sort(String propertyName, SortDirection sortDirection) {
	super();
	this.propertyName = propertyName;
	this.sortDirection = sortDirection;
}

public String getPropertyName() {
	return propertyName;
}

public void setPropertyName(String propertyName) {
	this.propertyName = propertyName;
}

public SortDirection getSortDirection() {
	return sortDirection;
}

public void setSortDirection(SortDirection sortDirection) {
	this.sortDirection = sortDirection;
}
  
  
}
