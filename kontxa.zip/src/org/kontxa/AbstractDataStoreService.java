package org.kontxa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.EntityNotFoundException;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.CompositeFilter;
import com.google.appengine.api.datastore.Query.CompositeFilterOperator;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Transaction;


public abstract class AbstractDataStoreService {
	
  protected final Logger LOG = Logger.getLogger(this.getClass().getName());
  private Map<String, Converter> converters = new HashMap<String, Converter>();
  
  public AbstractDataStoreService(Converter... converters) {
	  for(Converter converter : converters) {
		  this.converters.put(converter.getTarget().getName(), converter);  
	  }	  
  }
  public Filter getCompositeFilter(String propertyName, FilterOperator operator, String... tags) {
	  List<Filter> filters = new ArrayList<Filter>();
	  for(String tag : tags) {
		  Filter filter = new Query.FilterPredicate(propertyName,operator,tag);	
		  filters.add(filter);
	  }
	  CompositeFilter composite = CompositeFilterOperator.or(filters);
	  return composite;
  }
  public Filter getFilter(String propertyName, FilterOperator operator, String... tags) {
	  Filter filter = null;
	  if(tags.length > 1) {
		  filter = getCompositeFilter(propertyName, operator, tags);
	  }
	  else if(tags.length == 1){
		  filter = new Query.FilterPredicate(propertyName,operator,tags[0]);	
	  }
	  return filter;	  
  }
  public <T> List<T> list(Class<T> clazz, Filter filter, Sort... sorts) {
	  // Get the Datastore Service
	  DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();

	  // The Query interface assembles a query
	  Query q = new Query(clazz.getSimpleName());
	  
	  if(filter != null) {
		  q.setFilter(filter);
	  }
	  
	  for(Sort sort : sorts) {
		  q.addSort(sort.getPropertyName(), sort.getSortDirection());
	  }
	  
	  // PreparedQuery contains the methods for fetching query results
  	  // from the Datastore
	  PreparedQuery pq = datastore.prepare(q);

	  List objects = new ArrayList();
	  Converter<T> converter = getConverter(clazz);
	  
	  for (Entity entity : pq.asIterable()) {
		  T t = converter.convert(entity);
		  objects.add(t);
	  }	 
	  
	  return objects;
  }  
  public <T> List<T> list(Class<T> clazz) {
     List<T> list = list(clazz, null);
	 return list;
  }  
  public <T> T get(Class<T> clazz, long id) {
	try {
	  Key key = createKey(clazz, id);
	  DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
	  Entity entity = datastore.get(key);
	  Converter<T> converter = getConverter(clazz);
	  return converter.convert(entity);
	} catch (EntityNotFoundException e) {
		LOG.log(Level.SEVERE, "EntityNotFoundException while reading entity",e);
	} finally {
		//TODO
	}
	  return null;
  }
  public <T> T get(Class<T> clazz) {
	try {
	  Key key = createKey(clazz);
	  DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
	  Entity entity = datastore.get(key);
	  Converter<T> converter = getConverter(clazz);
	  return converter.convert(entity);
	} catch (EntityNotFoundException e) {
		LOG.log(Level.SEVERE, "EntityNotFoundException while reading entity",e);
	} finally {
		//TODO
	}
	  return null;
  }
  public <T> void delete(Class<T> clazz, long id) {
	  Key key = createKey(clazz, id);
	  DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
      datastore.delete(key);
  }
  public <T> void deleteTxn(Class<T> clazz, long id) {
	  Key key = createKey(clazz, id);
	  DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
	  Transaction txn = beginTransaction();
	  try {
	    datastore.delete(key);
		txn.commit();
	  }
	  finally {
	    rollback(txn);
	  }
  }
  protected Transaction beginTransaction() {
	  DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
	  Transaction txn = datastore.beginTransaction();
	  return txn;
  }
  protected void rollback(Transaction txn) {
	if (txn.isActive()) {
	  txn.rollback();
    }		  
  }
  public <T> Key save(T t) {
	  DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
	  Converter<T> converter = getConverter(t);
	  Entity entity = converter.convert(t);
  	  Key key = datastore.put(entity);
	  return key;		  
  }
  public <T> Key saveTxn(T t) {
	  DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
	  Converter<T> converter = getConverter(t);

	  Transaction txn = beginTransaction();
	  try {
		Entity entity = converter.convert(t);
		Key key = datastore.put(entity);
		txn.commit();
		return key;		  
	  }
	  finally {
		rollback(txn);
	  }
  }
  public <T> void clean(Class<T> clazz) {
  	  DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
  	  Query q = new Query(clazz.getSimpleName());
	  PreparedQuery pq = datastore.prepare(q);
	  List<Key> keys = new ArrayList<Key>();
	  for (Entity result : pq.asIterable()) {
		  keys.add(result.getKey());
	  }	  
	  for(Key key : keys) {
		  datastore.delete(key);
	  }
  }
  
  protected <T> Converter<T> getConverter(T t) {
	  return converters.get(t.getClass().getName());
  }
  protected <T> Converter<T> getConverter(Class<T> clazz) {
	  return converters.get(clazz.getName());
  }
  protected Key createKey(Class clazz) {	
	  return KeyFactory.createKey(clazz.getSimpleName(), clazz.getSimpleName());	  
  }
  protected Key createKey(Class clazz, long id) {	
	  return KeyFactory.createKey(clazz.getSimpleName(), id);	  
  }
}
