package org.kontxa;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;


public class DataStoreService extends AbstractDataStoreService implements Service {
	
  protected final Logger LOG = Logger.getLogger(this.getClass().getName());
  
  public DataStoreService() {
	  super(new ConverterFactory().getOptionsConverter(), new ConverterFactory().getNoteConverter(), new ConverterFactory().getCategoryConverter());
  }

public void reindex() {
	  List<Note> notes = listAll();
	  for(int i=0;i<notes.size();i++) {
		  Note note = notes.get(i);
		  if(note.getOrder() != i) {
			  note.setOrder(i);
			  update(note);
		  }
	  }
  }
	  
  public Note createNote(String text, String type, Long categoryId) {
	  Date creationDate = new Date();
	  
	  Note note = new Note();
	  note.setCreationDate(creationDate);	  
	  note.setModificationDate(creationDate);
	  note.setCategoryId(categoryId);
	  note.setText(text);
	  note.setType(type);

	  List<Note> notes = listAll();
	  note.setOrder(notes.size());

	  Key key = saveTxn(note);
	  
	  note.setId(new Long(key.getId()));
	  
	  return note;
  }
  public void clean() {
	  clean(Note.class);
  }
  public Note update(Note note) {
	  note.setModificationDate(new Date());
	  saveTxn(note);
	  return note;
  }
  
  public Options readOptions() {
	  Options options = get(Options.class);
		if(options == null) {
			options = new Options();
			options.setAuthMode("public");
			options.setEditor("markdown");
			options.setRssMode("normal");
			options.getColors().add("blue");
			options.getColors().add("red");
			options.getColors().add("green");	
			
			update(options);
		}
	  return options;
  }  
  public Options update(Options options) {
	  options.setModificationDate(new Date());
	  saveTxn(options);

	  return options;
  }  
  public List<Note> listAll() {
	  List<Note> notes = list(Note.class, null);
	  return sort(notes);
  }
  public List<Note> list() {
	  long start = System.currentTimeMillis();
	  Filter filter = new Query.FilterPredicate("categoryId",FilterOperator.NOT_EQUAL,getTrash().getId());
	  List<Note> notes = list(Note.class, filter);
	  long middle = System.currentTimeMillis();
	  notes = sort(notes);
	  long end = System.currentTimeMillis();
	  LOG.info("list notes : "+(end - start)+" access "+(middle - start)+" sort "+(end - middle));
	  return notes;
  }
  public List<Note> listByCategories(List<Long> categoryIds) {
	  long start = System.currentTimeMillis();	 
//	  LOG.info("listByCategories "+categoryIds);
	  Filter filter = new Query.FilterPredicate("categoryId",FilterOperator.IN,categoryIds);
	  List<Note> notes = list(Note.class, filter);
	  long middle = System.currentTimeMillis();
//	  LOG.info("list notes size "+notes.size());
	  notes = sort(notes);
	  long end = System.currentTimeMillis();
	  LOG.info("list notes : "+(end - start)+" access "+(middle - start)+" sort "+(end - middle)+" size "+notes.size());
	  return notes;
  }
  public List<Note> list(List<String> ids) {
	  List<Note> notes = list();
	  return notes;
  }
  
  public Note read(long id) {
		return get(Note.class, id);
  }
  public Note delete(long id) {
	  Note note = read(id);
	  if(note != null) {
		  if(note.getCategoryId().equals(getTrash().getId())) {
			  deleteTxn(Note.class, id);	
			  note = null;
		  }
		  else {
			  note.setCategoryId(getTrash().getId());
			  update(note);			  
		  }
	  }
	  return note;
  }
  public Note truncate(long id) {
	  Note note = read(id);
	  if(note != null && note.getCategoryId().equals(getTrash().getId())) {
		  deleteTxn(Note.class, id);
	  }
	  return note;
  }
  public Note restore(long id) {
	  Note note = read(id);
	  if(note != null) {
		  note.setCategoryId(null);  
		  update(note);
	  }
	  return note;
  }
  private List sort(List list) {
	  Collections.sort(list, new OrderComparator());
	  return list;
  }
  public void swap(long id1, long id2) {
	  Note note1 = read(id1);
	  Note note2 = read(id2);
	  
	  Integer order1 = note1.getOrder();
	  Integer order2 = note2.getOrder();
	  
	  note1.setOrder(order2);
	  note2.setOrder(order1);
	  
	  update(note1);
	  update(note2);
	  
  }  
  public List<Note> findByTags(String... tags) {
	  Filter filter = getFilter("tags", FilterOperator.EQUAL, tags);
	  List<Note> notes = list(Note.class, filter);
	  return sort(notes);
  }
  public List<Note> findByText(String... text) {
	  List<Note> notes = list();
	  List<Note> snotes = new ArrayList<Note>();
	  for(Note note : notes) {
		 for(String t : text) {
			 if(note.getText().contains(t)) {
				 snotes.add(note);
				 break;
			 }
		 }
	  }
	  return snotes;
  }

@Override
public List<Category> listCategories() {
	  long start = System.currentTimeMillis();
	  List<Category> categories = list(Category.class);
	  long middle = System.currentTimeMillis();
	  categories = sort(categories);
	  long end = System.currentTimeMillis();
	  LOG.info("list categories : "+(end - start)+" access "+(middle - start)+" sort "+(end - middle)+" size "+categories.size());
	  return categories;
}

@Override
public Category update(Category category) {
	  saveTxn(category);
	  return category;
}
public Category createCategory(String title, String color) {
	  Category category = new Category();
	  category.setTitle(title);
	  category.setColor(color);

	  List<Category> categories = listCategories();
	  category.setOrder(categories.size());

	  Key key = saveTxn(category);
	  
	  category.setId(new Long(key.getId()));
	  
	  return category;
}

@Override
public Category readCategory(long id) {
	return get(Category.class, id);
}

@Override
public Category getTrash() {
	List<Category> categories = listCategories();
	for(Category category : categories) {
		if("Trash".equals(category.getTitle())) {
			return category;
		}
	}
	return null;
}

}
