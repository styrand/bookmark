package org.kontxa;

import com.google.appengine.api.datastore.Entity;

public interface Converter<T> {
	  public T convert(Entity entity);
	  
	  public Entity convert(T t);
	  
	  public Class<T> getTarget();
}
