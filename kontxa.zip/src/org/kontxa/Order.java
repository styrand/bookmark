package org.kontxa;

public interface Order {
  public Integer getOrder();
}
