package org.kontxa;

import java.io.Serializable;

public class Message implements Serializable {
	private String level;

	private String text;
	
	public static Message createInfoMessage(String text) {
		Message message = new Message();
		message.setLevel("info");
		message.setText(text);
		return message;
	}
	public static Message createErrorMessage(String text) {
		Message message = new Message();
		message.setLevel("error");
		message.setText(text);
		return message;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
}
