package org.kontxa.action;

import java.io.IOException;
import java.util.logging.Level;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 */
public class KontxaServlet extends AbstractKontxaServlet {
    public void init(ServletConfig config) throws ServletException {   
        super.init(config);  
        
        
//        Options options = getService().readOptions();
//        options.setAuthMode("public");
//		getService().update(options);

//        getService().reindex();
//        
//        getService().clean();
//        for(int i=0;i<10;i++) {
//        	String s = "note "+i;
//            getService().create(s, null, i, null);        	
//        }
    }
	
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
    		forwardToHome(req, resp);
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "Exception in class "+this.getClass().getName(),e);			
		}
    }
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	doGet(req, resp);
    }
}