package org.kontxa.action;

import java.io.IOException;
import java.util.logging.Level;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kontxa.Options;

/**
 *
 */
public class EditorServlet extends AbstractKontxaServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
    		String id = getParam(req);
    		LOG.info(this.getClass().getName()+" "+id);
    		Options options = getService().readOptions();
    		if("rich".equals(id) && !"rich".equals(options.getEditor())) {
    			options.setEditor("rich");
    			options = getService().update(options);
//       			addInfoMessage(req, "message", "Note Editor set to 'rich'.");
    		}
    		if("markdown".equals(id) && !"markdown".equals(options.getEditor())) {
    			options.setEditor("markdown");
    			options = getService().update(options);
//       			addInfoMessage(req, "message", "Note Editor set to 'markdown'.");
    		}
    		if("plain".equals(id) && !"plain".equals(options.getEditor())) {
    			options.setEditor("plain");
    			options = getService().update(options);
//       			addInfoMessage(req, "message", "Note Editor set to 'markdown'.");
    		}
   			forwardToHome(req, resp);
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "Exception in class "+this.getClass().getName(),e);			
		}
    }
}