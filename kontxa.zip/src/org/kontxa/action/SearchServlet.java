package org.kontxa.action;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kontxa.Note;

/**
 *
 */
public class SearchServlet extends AbstractKontxaServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
    		String search = req.getParameter("search");
    		List<Note> notes = null;
    		if(search != null && search.length() > 0) {
    			if(search.indexOf(' ') != -1) {
    				notes = getService().findByText(search.split(" "));	
    			}
    			else {
    				notes = getService().findByText(search);
    			}
        		    			
    		}
    		if(notes != null && notes.size() > 0) {
        		req.setAttribute("notes", notes);
    			req.setAttribute("search", search);
    			setOptions(req);
        		req.getRequestDispatcher("/search.jsp").forward(req, resp);        		
    		}
    		else {
    			addInfoMessage(req, "No notes not found for '"+search+"'");
    			req.setAttribute("search", search);
    			forwardToHome(req, resp);
    		}
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "Exception in class "+this.getClass().getName(),e);			
		}
    }
}