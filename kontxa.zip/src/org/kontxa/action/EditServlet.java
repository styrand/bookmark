package org.kontxa.action;

import java.io.IOException;
import java.util.logging.Level;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 */
public class EditServlet extends AbstractKontxaServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
    		Long id = getParamAsLong(req);
    		LOG.info(this.getClass().getName()+" "+id+" "+req.getServletPath());
    		req.setAttribute("mode", req.getServletPath().substring(1));
    		req.setAttribute("note", getService().read(id));
			forwardToHome(req, resp);
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "Exception in class "+this.getClass().getName(),e);			
		}
    }
}