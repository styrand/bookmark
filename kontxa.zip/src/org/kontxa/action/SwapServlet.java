package org.kontxa.action;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 */
public class SwapServlet extends AbstractKontxaServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
    		List<String> ids = getParams(req);
    		Long src = new Long(ids.get(0));
    		Long dest = new Long(ids.get(1));
    		LOG.info(this.getClass().getName()+" "+src+" -> "+dest);
    		getService().swap(src, dest);
			redirectToHome(req, resp);
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "Exception in class "+this.getClass().getName(),e);			
		}
    }
}