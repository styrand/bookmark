package org.kontxa.action;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kontxa.Category;
import org.kontxa.Color;
import org.kontxa.Options;

/**
 */
public class OptionsServlet extends AbstractKontxaServlet {
    public void init(ServletConfig config) throws ServletException {   
        super.init(config);  
    }
	
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
			Options options = getService().readOptions();
    		String id = getParam(req);
    		LOG.info("id : "+id);
    		if("reindex".equals(id)) {
    			getService().reindex();    	
    			addInfoMessage(req, "Notes reindexed");
    		}
    		else if("clean".equals(id)) {
    			getService().clean();    	
    			addInfoMessage(req, "Database cleaned : all notes deleted");
    		}
    		else if("auth/private".equals(id)) {
    			options.setAuthMode("private");
    			options = getService().update(options);
       			addInfoMessage(req, "Authentication mode set to 'private'.");
   			}
    		else if("auth/protected".equals(id)) {
    			options.setAuthMode("protected");
    			options = getService().update(options);
       			addInfoMessage(req, "Authentication mode set to 'protected'.");
    		}
    		else if("auth/public".equals(id)) {
    			options.setAuthMode("public");
    			options = getService().update(options);
       			addInfoMessage(req, "Authentication mode set to 'public'.");
    		}
    		else if("compact_rss".equals(id)) {
    			options.setRssMode("compact");
    			options = getService().update(options);
       			addInfoMessage(req, "Rss mode set to 'compact'.");
    		}
    		else if("normal_rss".equals(id)) {
    			options.setRssMode("normal");
    			options = getService().update(options);
       			addInfoMessage(req, "Rss mode set to 'normal'.");
    		}
    		else if("category".equals(id)) {
        		String idCategory = req.getParameter("id");
        		String title = req.getParameter("title");
        		String color = req.getParameter("color");
        		
        		if(title == null || title.trim().length() == 0) {
        			addErrorMessage(req, "Title is empty ! ");
        		}
        		else if(idCategory == null) {
            		if(exists(title)){
        				addErrorMessage(req, "Another category already exists with this title ! ");        			
            		}
            		else {
            			getService().createCategory(title, color);
               			addInfoMessage(req, "Category '"+title+"' saved.");            			
            		}
        		}
        		else {
            		Long lid = null;
            		if(idCategory != null) {
                		lid = new Long(idCategory);    			
            		}
           			Category category = getService().readCategory(lid);
           			category.setTitle(title);
           			category.setColor(color);
          			getService().update(category);
           			addInfoMessage(req, "Category '"+title+"' saved.");
        		}    			
    		}
    		req.setAttribute("options", options);
    		req.setAttribute("colors", Color.getColors());
    		req.setAttribute("categories", getService().listCategories());
    		req.getRequestDispatcher("/options.jsp").forward(req, resp);
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "Exception in class "+this.getClass().getName(),e);			
		}
    }
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	doGet(req, resp);
    }
    private boolean exists(String title) {
		List<Category> categories = getService().listCategories();
		for(Category category : categories) {
			if(title.equals(category.getTitle())) {
				return true;
			}
		}
		return false;
    	
    }
}