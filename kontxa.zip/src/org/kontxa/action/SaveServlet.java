package org.kontxa.action;

import java.io.IOException;
import java.util.logging.Level;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kontxa.Note;

/**
 */
public class SaveServlet extends AbstractKontxaServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
    		String id = req.getParameter("id");
    		String text = req.getParameter("text");
    		String categoryId = req.getParameter("categoryId");
    		String type = req.getParameter("type");
    		Note note = null;
    		
    		LOG.info("note "+categoryId+" "+id);
    		
    		Long lid = null;
    		if(id != null) {
        		lid = new Long(id);    			
    		}
    		
    		if(text == null || text.trim().length() == 0) {
    			addFlashErrorMessage(req, "Note is empty ! ");
	    		if(lid != null) {
	        		note = getService().read(lid);    			
	    		}
    		}
    		else {
        		Long cid = null;
        		if(categoryId != null) {
        			cid = new Long(categoryId);    			
        		}
	    		if(lid != null) {
	        		note = getService().read(lid);    			
	        		note.setText(text);
	        		note.setCategoryId(cid);	    
	        		getService().update(note);
	    			addFlashInfoMessage(req, "Note '"+note.formatTitle()+"' saved");
	    		}
	    		else {
	    			note = getService().createNote(text, type, cid);
	    			addFlashInfoMessage(req, "Note '"+note.formatTitle()+"' saved");
	    		}
		   }
    		
   		   req.setAttribute("flash.note", note);
		   redirectToHome(req, resp);
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "Exception in class "+this.getClass().getName(),e);			
		}
    }
}