package org.kontxa.action;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kontxa.Category;

/**
 */
public class CategoryServlet extends AbstractKontxaServlet {
    public void init(ServletConfig config) throws ServletException {   
        super.init(config);  
//        List<Category> cats = getService().listCategories();
//        for(Category c : cats) {
//        	c.setOrder(0);
//        	getService().update(c);
//        }
        Category trash = getService().getTrash();
        if(trash == null) {
            trash = getService().createCategory("Trash","Black");
            trash.setOrder(Integer.MAX_VALUE);
            getService().update(trash);
        }
    }
	
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
    		List<String> ids = getParams(req);  
    		String action = ids.get(0);
    		Long id = new Long(ids.get(1));
    		LOG.info("id : "+id);
    		if("close".equals(action)) {
    			Category category = getService().readCategory(id);
    			category.setOpen(false);
    			getService().update(category);
    			addInfoMessage(req, "Category '"+category.getTitle()+"' closed.");
    		}
    		else if("open".equals(action)) {
    			Category category = getService().readCategory(id);
    			category.setOpen(true);
    			getService().update(category);
    			addInfoMessage(req, "Category '"+category.getTitle()+"' opened.");
    		}
			forwardToHome(req, resp);
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "Exception in class "+this.getClass().getName(),e);			
		}
    }
}