package org.kontxa.action;

import java.util.Collection;
import java.util.List;

import org.kontxa.Category;
import org.kontxa.Note;
import org.kontxa.Options;

public class TagLibFunctions {
	public static boolean equals(Object o1, Object o2) {
		return o1.equals(o2);
	}
	public static boolean contains(Collection c, Object element) {
		return c.contains(element);
	}
	public static int size(Collection c) {
		return c.size();
	}
	public static String formatLongTitle(Note note) {
		return note.formatLongTitle();
	}
	public static String formatTitle(Note note) {
		return note.formatTitle();
	}
	public static String formatTags(Note note) {
		return note.formatTags();
	}
	public static String formatBgColor(Note note) {
		return note.formatBgColor();
	}
	public static String formatColor(Note note, String color) {
		return note.formatColor(color);
	}
	public static String formatBgColor(Category category) {
		return category.formatBgColor();
	}
	public static String formatColor(Category category, String color) {
		return category.formatColor(color);
	}
	public static String formatBorderColor(Note note) {
		return note.formatBorderColor();
	}
	public static String formatHtml(Note note) {
		return note.formatHtml();
	}
	public static String formatSearch(Note note, String search) {
		return note.formatSearch(search);
	}
	public static String formatSelectedNotes(Options options) {
		return options.formatSelectedNotes();
	}
	public static boolean canWrite(Options options) {
		if(options != null) {
			return options.canWrite();			
		}
		
		return false;
	}
	public static boolean isEditMode(Options options, String mode) {
		return options.isEditMode(mode);
	}
	public static boolean activateRichEditor(Options options, Note note) {
		if(note != null) {
			return "rich".equals(note.getType());
		}
		if(options != null) {
			return "rich".equals(options.getEditor());			
		}
		return false;
	}
	public static int rowNumber(Note note) {
		String text = note.getText();
		if(text != null) {
		  String[] lines = text.split(System.getProperty("line.separator"));
		  return Math.max(20, lines.length);
		}
		return 20;
	}
	public static String selected(Object o1, Object o2) {
		if(o1.equals(o2)) {
			return "selected";
		}
		return "";
	}
	public static String formatStyle(String att, Object id, List<Category> categories) {
		for(Category category : categories) {
			if(category.getId().equals(id)) {
				String color = category.getColor();
				if(color != null && color.length() > 0) {
					return "style=\""+att+":"+color+";\"";
				}				
			}
		}
		return "";
	}
	public static String formatStyle(String att, String color) {
		if(color != null && color.length() > 0) {
			return "style=\""+att+":"+color+";\"";
		}				
		return "";
	}
	public static String escapeJavaScript(String s) {
		s = s.replace("'","\\'");
//		s = s.replace("\"","&quot;");
		
		return s;
	}
}
