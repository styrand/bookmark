package org.kontxa.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kontxa.Category;
import org.kontxa.Color;
import org.kontxa.DataStoreService;
import org.kontxa.Message;
import org.kontxa.Note;
import org.kontxa.Options;
import org.kontxa.Service;

/**
 */
public abstract class AbstractKontxaServlet extends HttpServlet {
    protected final Logger LOG = Logger.getLogger(this.getClass().getName());
	
    public List<String> getParams(HttpServletRequest req) {
    	String pathInfo = req.getPathInfo();
    	if(pathInfo != null) {
        	String[] splitPath = pathInfo.split("/");
        	if(splitPath != null && splitPath.length > 0) {
        		List<String> params = new ArrayList<String>();
        		for(String p : splitPath) {
        			p = p.trim();
        			if(p.length() > 0) {
        				params.add(p);
        			}
        		}
        		return params;
        	}    		
    	}
    	return null;
    }
    public String getParam(HttpServletRequest req) {
    	String s = req.getPathInfo();
    	if(s != null && s.startsWith("/")) {
    		return s.trim().substring(1);
    	}
    	return null;
    }
    public Long getParamAsLong(HttpServletRequest req) {
    	String s = getParam(req);
    	if(s != null) {
    		return new Long(s);
    	}
    	return null;
    }
    public Service getService() {
    	return new DataStoreService();
    }
    public void setOptions(HttpServletRequest req) throws ServletException, IOException {
  		Options options = getService().readOptions();
  		req.setAttribute("options", options);	  
    }
    public void forwardToHome(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	List<Long> catIds = new ArrayList<Long>();
  		List<Category> categories = getService().listCategories();
  		categories.add(0, new Category(-1L, "", -1, true));
  		for(Category category : categories) {
  			if(category.getOpen()) {
  				catIds.add(category.getId());
  			}
  		}
  		List<Note> notes = getService().listByCategories(catIds);
  		for(Note note : notes) {
  			Category category = findCategory(note.getCategoryId(), categories); 
			category.getNotes().add(note);
  		}
  		req.setAttribute("categories", categories);	  
  		setOptions(req);
  		req.setAttribute("colors", Color.getColors());	  
  		req.getRequestDispatcher("/kontxa.jsp").forward(req, resp);
    }
    public void redirectToHome(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	List<Long> catIds = new ArrayList<Long>();
  		List<Category> categories = getService().listCategories();
  		categories.add(0, new Category(-1L, "", -1, true));
  		for(Category category : categories) {
  			if(category.getOpen()) {
  				catIds.add(category.getId());
  			}
  		}
  		List<Note> notes = getService().listByCategories(catIds);
  		for(Note note : notes) {
  			Category category = findCategory(note.getCategoryId(), categories); 
			category.getNotes().add(note);
  		}
  		req.setAttribute("flash.categories", categories);	  
  		Options options = getService().readOptions();
  		req.setAttribute("flash.options", options);	  
  		req.setAttribute("flash.colors", Color.getColors());	  
//  		req.getRequestDispatcher("/kontxa.jsp").forward(req, resp);
  		resp.sendRedirect("/kontxa.jsp");
    }
    private Category findCategory(Long categoryId, List<Category> categories) {
		for(Category category : categories) {
			if(category.getId().equals(categoryId)) {
				return category;
			}
		}
		return categories.get(0);
	}

	public void addInfoMessage(HttpServletRequest req, String text) {
		Message message = Message.createInfoMessage(text) ;
		req.setAttribute("message", message);    		    		    	
    }
    public void addErrorMessage(HttpServletRequest req, String text) {
		Message message = Message.createErrorMessage(text) ;
		req.setAttribute("message", message);    		    		    	
    }
	public void addFlashInfoMessage(HttpServletRequest req, String text) {
		Message message = Message.createInfoMessage(text) ;
		req.setAttribute("flash.message", message);    		    		    	
    }
    public void addFlashErrorMessage(HttpServletRequest req, String text) {
		Message message = Message.createErrorMessage(text) ;
		req.setAttribute("flash.message", message);    		    		    	
    }

	@Override
    public void init(ServletConfig config) throws ServletException {   
        super.init(config);        
        LOG.info("Initialisation de la servlet "+this.getClass().getName()+" ...");
    }
    
	@Override
	public void destroy() {
		super.destroy();
        LOG.info("Arret de la servlet "+this.getClass().getName()+" ...");
	}
    
}