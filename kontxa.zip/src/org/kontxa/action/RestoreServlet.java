package org.kontxa.action;

import java.io.IOException;
import java.util.logging.Level;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kontxa.Note;

/**
 *
 */
public class RestoreServlet extends AbstractKontxaServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
    		Long id = getParamAsLong(req);
    		LOG.info(this.getClass().getName()+" "+id);
    		Note note = getService().restore(id);

    		addFlashInfoMessage(req, "Note '"+note.formatTitle()+"' restored");    		    					
    		
   			redirectToHome(req, resp);
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "Exception in class "+this.getClass().getName(),e);			
		}
    }
}