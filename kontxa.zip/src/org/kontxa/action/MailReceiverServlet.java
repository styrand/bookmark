package org.kontxa.action;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;

import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.geronimo.mail.util.Base64DecoderStream;

/**
 *
 */
public class MailReceiverServlet extends AbstractKontxaServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException {
		try {
			Properties props = new Properties();
			Session session = Session.getDefaultInstance(props, null);
			MimeMessage message = new MimeMessage(session, req.getInputStream());
			String contentType = message.getContentType();
			LOG.info("Receive mail of type "+contentType+" -> create new note ...");
			Object content = message.getContent();
			if (content instanceof String) {
				String scontent = (String)content;
				LOG.info("Receive mail ["+scontent+"] -> create new note ...");
				if(scontent == null || scontent.trim().length() > 0) {
					getService().createNote((String)content, null, null);					
				}
			} else if (content instanceof Multipart) {
				// A multipart body.
				for (int i = 0; i < ((Multipart) content).getCount(); i++) {
					Part part = ((Multipart) content).getBodyPart(i);
					if(part.getContentType().startsWith("text/x-vnote")) {
						Base64DecoderStream decoder = (Base64DecoderStream)part.getContent();
					      
					    InputStream is = MimeUtility.decode(decoder,"base64");
					    byte[] buffer = new byte[4096];
					    ByteArrayOutputStream bos = new ByteArrayOutputStream();
					    int read;
					    while ((read = is.read(buffer)) > 0) {
					     bos.write(buffer, 0, read);
					    }
					      
					    String s = new String(bos.toByteArray());
//					      if(s.startsWith("BEGIN:VNOTE")) {
//					    	  
//					      }
						LOG.info("Receive mail with part "+part.getContentType()+"-"+part.getDisposition()+" "+part.getContent()+" -> create new note ...");
						getService().createNote(s, null, null);
					}
				}
			}
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "Exception in class "+ this.getClass().getName(), e);
		}
	}
}