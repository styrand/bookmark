package org.kontxa.action;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kontxa.Category;
import org.kontxa.Item;
import org.kontxa.Note;
import org.kontxa.Options;
import org.kontxa.Rss;
import org.kontxa.RssFeedWriter;

/**
 *
 */
public class RssServlet extends AbstractKontxaServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
    		List<String> ids = getParams(req);
    		LOG.info(this.getClass().getName()+" "+ids);
    		List<Note> notes = null;
    		List<Category> categories = null;
    		
    		if(ids ==null) { 			
        		notes = getService().list();    			    			
    		}
    		else if(ids.size() ==1) {
        		String id = ids.get(0);
				if("all".equals(id)) {
            		notes = getService().list();    			    			
        		}
				else if("allcat".equals(id)) {
            		categories = getService().listCategories();    			    			
        		}
        		else {
        			Long lid = new Long(id);
        			notes = new ArrayList<Note>();
            		notes.add(getService().read(lid));    		
        		}    			
    		}
    		else {
        		String id = ids.get(0);
				if("cat".equals(id)) {
					Long lid = new Long(ids.get(1));
					List<Long> list = new ArrayList<Long>();
					list.add(lid);
            		notes = getService().listByCategories(list);    			    			
        		}
				else {
	    			notes = getService().list(ids);					
				}
    		}
    		
        	// Create the rss feed
    		String copyright = "S Tyrand";
    		String title = "Kontxa";
    		if(categories != null) {
    			title = title + " Categories";
    		}
    		String description = "Kontxa";
    		String language = "fr";
    		String link = req.getRequestURL().toString();
    		int io = link.indexOf("://");
    		if(io != -1) {
    			int io2 = link.indexOf("/", io + 4);
    			if(io2 != -1) {
    				link = link.substring(0, io2);
    			}
    		}
    		Calendar cal = new GregorianCalendar();
    		cal.add(Calendar.HOUR, 1);
    		Date creationDate = cal.getTime();
    		String pubdate = formatDate(creationDate);
    		Rss rss = new Rss(title, link, description, language,
    				copyright, pubdate);
    		
    		Options options = getService().readOptions();
    		String rssMode = options.getRssMode();
    		
    		if(notes != null) {

        		// Now add one example entry
        		for(Note note : notes) {
        			Item item = new Item();
        			item.setTitle(note.formatTitle());
        			if("compact".equals(rssMode)) {
            			item.setDescription(note.formatCompactHtml());    				
        			}
        			else {
            			item.setDescription(note.formatHtml());    				
        			}
        			item.setAuthor("S Tyrand");
        			item.setGuid(link+"/view/"+note.getId()+"-"+new SimpleDateFormat("ddMMyyyyHHmmss").format(note.getModificationDate()));
        			item.setLink(link+"/view/"+note.getId());
        			item.setPubdate(formatDate(note.getModificationDate()));
        			rss.getItems().add(item);			
        		}    			
    		}
    		
    		else if(categories != null) {
        		// Now add entries
        		for(Category cat : categories) {
        			Item item = new Item();
        			item.setTitle(cat.getTitle());
           			item.setDescription(cat.getTitle());    				
        			item.setAuthor("S Tyrand");
        			item.setGuid(link+"/rss/cat/"+cat.getId()+"-"+new SimpleDateFormat("ddMMyyyyHHmmss").format(new Date()));
        			item.setLink(link+"/rss/cat/"+cat.getId());
        			item.setPubdate(formatDate(new Date()));
        			rss.getItems().add(item);			
        		}    			    			
    		}

    		// Now write the file
    		RssFeedWriter writer = new RssFeedWriter(rss);
    		
			resp.setContentType("text/xml");
//			Iterator<String> keys = headers.keySet().iterator();
//			while(keys.hasNext()) {
//				String key = keys.next();
//				for(String s : headers.get(key)) {
//					if(resp.containsHeader(key)) {
//						resp.addHeader(key, s);																		
//					}
//					else {
//						resp.setHeader(key, s);
//					}
//				}
//			}
            ServletOutputStream out = resp.getOutputStream();
            
            writer.write(out);
            out.flush();
            out.close();

    	} catch (Exception e) {
			LOG.log(Level.SEVERE, "Exception in class "+this.getClass().getName(),e);			
		}
    }
	private static String formatDate(Date date) {
		SimpleDateFormat date_format = new SimpleDateFormat(
				"EEE', 'dd' 'MMM' 'yyyy' 'HH:mm:ss' 'Z", Locale.US);
		String sdate = date_format.format(date);
		
		return sdate;
    	
    }
}