package org.kontxa.action;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kontxa.Note;
import org.kontxa.NotesWriter;

/**
 *
 */
public class XmlServlet extends AbstractKontxaServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
    		LOG.info(this.getClass().getName());
      		List<Note> notes = getService().list();

    		// Now write the file
    		NotesWriter writer = new NotesWriter(notes);
    		
			resp.setContentType("text/xml");
//			Iterator<String> keys = headers.keySet().iterator();
//			while(keys.hasNext()) {
//				String key = keys.next();
//				for(String s : headers.get(key)) {
//					if(resp.containsHeader(key)) {
//						resp.addHeader(key, s);																		
//					}
//					else {
//						resp.setHeader(key, s);
//					}
//				}
//			}
            ServletOutputStream out = resp.getOutputStream();
            
            writer.write(out);
            out.flush();
            out.close();

    	} catch (Exception e) {
			LOG.log(Level.SEVERE, "Exception in class "+this.getClass().getName(),e);			
		}
    }
}