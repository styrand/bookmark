package org.kontxa.action;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kontxa.Note;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;

/**
 */
public class PdfServlet extends AbstractKontxaServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse response) throws IOException {
    	try {
    		List<String> ids = getParams(req);
    		LOG.info(this.getClass().getName()+" "+ids);
    		List<Note> notes = null;
    		
    		if(ids.size() ==1) {
        		String id = ids.get(0);
				if("all".equals(id)) {
            		notes = getService().list();    			    			
        		}
        		else {
            		Long lid = new Long(id);
        			notes = new ArrayList<Note>();
            		notes.add(getService().read(lid));    		
        		}    			
    		}
    		else {
    			notes = getService().list(ids);
    		}
    		
    		if(notes != null && notes.size() > 0) {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                createPdf(notes, baos);
                // setting some response headers
                response.setHeader("Expires", "0");
                response.setHeader("Cache-Control",
                    "must-revalidate, post-check=0, pre-check=0");
                response.setHeader("Pragma", "public");
                // setting the content type
                response.setContentType("application/pdf");
                // the contentlength
                response.setContentLength(baos.size());
                // write ByteArrayOutputStream to the ServletOutputStream
                OutputStream os = response.getOutputStream();
                baos.writeTo(os);
                os.flush();
                os.close();                			
    		}
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "Exception in class "+this.getClass().getName(),e);			
		}
    }
    /**
     * Creates a list with movies in HTML and PDF simultaneously.
     * @param html a path to the resulting HTML file
     * @param pdf a path to the resulting PDF file
     * @throws SQLException
     * @throws IOException
     * @throws DocumentException
     */
    private void createPdf(List<Note> notes, OutputStream os) throws IOException, DocumentException {
        // step 1
        Document document = new Document();
        // step 2
        PdfWriter writer = PdfWriter.getInstance(document, os);
        // step 3
        document.open();
        // step 4
        for (Note note : notes) {
            // create the snippet
            String snippet = note.formatHtml();
            // use the snippet for the PDF document
            try {
                XMLWorkerHelper.getInstance().parseXHtml(writer, document, new StringReader(snippet));         	
                document.newPage();
            }
            catch(Throwable t) {
            	LOG.log(Level.SEVERE, "Error while parsing html note ["+note+"] snippet ["+snippet+"]",t);
            }
        }
        // step 5
        document.close();
    }
	
}