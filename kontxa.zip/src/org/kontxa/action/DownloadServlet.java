package org.kontxa.action;

import java.io.IOException;
import java.util.logging.Level;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kontxa.Note;

/**
 *
 */
public class DownloadServlet extends AbstractKontxaServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
    		String id = getParam(req);
    		LOG.info(this.getClass().getName()+" "+id);
    		
    		if(id !=null) { 			
       			Long lid = new Long(id);
           		Note note = getService().read(lid);    		
    		    String content = note.getText();
				resp.setContentType("text/plain");
		        resp.setContentLength(content.length() );
		        String filename = note.getId().toString();
		        resp.setHeader( "Content-Disposition", "attachment; filename=\"" + filename +".txt" + "\"" );
				
	            ServletOutputStream out = resp.getOutputStream();
	            
	            out.write(note.getText().getBytes());
	            out.flush();
	            out.close();
    		}

    	} catch (Exception e) {
			LOG.log(Level.SEVERE, "Exception in class "+this.getClass().getName(),e);			
		}
    }
//	private String replace(String s) {
//		char[] charToReplace = {'à', 'â' , 'ä' ,  'é' , 'è' , 'ê' , 'ë' , 'ï' , 'î', 'ô' , 'ö' , 'ü' , 'û' , 'ù'  } ;
//		char[] charReplaced =  {'a', 'a' , 'a' ,  'e' , 'e' , 'e' , 'e' , 'i' , 'i', 'o' , 'o' , 'u' , 'u' , 'u'  } ;
//		
//		for(int i=0;i<charToReplace.length;i++) {
//			s = s.replace(charToReplace[i], charReplaced[i]);
//			s = s.replace(Character.toUpperCase(charToReplace[i]), Character.toUpperCase(charReplaced[i]));
//		}
//		return s;
//		
//	}
}