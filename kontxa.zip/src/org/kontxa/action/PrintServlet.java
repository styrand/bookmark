package org.kontxa.action;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kontxa.Note;

/**
 */
public class PrintServlet extends AbstractKontxaServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
    	try {
    		List<String> ids = getParams(req);
    		LOG.info(this.getClass().getName()+" "+ids);
    		
    		if(ids == null) {
    			List<Note> notes = getService().list();
    			req.setAttribute("notes", notes);      			
    		}
    		else if(ids.size() ==1) {
        		String id = ids.get(0);
				if("all".equals(id)) {
            		req.setAttribute("notes", getService().list());    			    			
        		}
        		else {
        			Long lid = new Long(id);
            		req.setAttribute("note", getService().read(lid));    			
        		}    			
    		}
    		else {
    			List<Note> notes = getService().list(ids);
    			req.setAttribute("notes", notes);  
    		}
    		req.getRequestDispatcher("/print.jsp").forward(req, resp);
		} catch (Exception e) {
			LOG.log(Level.SEVERE, "Exception in class "+this.getClass().getName(),e);			
		}
    }
}