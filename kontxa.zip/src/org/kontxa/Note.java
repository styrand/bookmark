package org.kontxa;

import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.markdown4j.ExtDecorator;
import org.markdown4j.Markdown4jProcessor;

public class Note implements Serializable, Order {
    protected final transient Logger LOG = Logger.getLogger(this.getClass().getName());

    private Long id;
	
	private Long categoryId;
	
	private String text;
	
	private String type;

	private Integer order;

	private Date creationDate;

	private Date modificationDate;

	private Set<String> tags = new LinkedHashSet<String>();
	
	private Category category;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	private String formatTitle(int length) {
		String title = null;
		if("rich".equals(type)) {
			Document doc = Jsoup.parseBodyFragment(this.text);
			Element body = doc.body();
			title = body.text();
		}
		else {
			title = this.text;
		}
		int io = title.indexOf(System.getProperty("line.separator"));
		if(io != -1 && io < length + 5) {
			title = title.substring(0, io);							
		}
		if(title.length() > length) {
			title = title.substring(0, length); //+" ...";	
		}
		return title.trim();			
	}
	public String formatTitle() {
		return formatTitle(50);
	}
	public String formatLongTitle() {
		return formatTitle(100);
	}
	public String formatHtml() {
		StringBuffer sb = new StringBuffer();
		if(text != null) {
			if("rich".equals(type)) {
				sb.append(text);				
			}
			else if("markdown".equals(type)){
				try {
					String html = new Markdown4jProcessor().addHtmlAttribute("style", "color:red", "blockquote").addHtmlAttribute("target", "_blank", "a").process(text);
					sb.append(html);
				} catch (IOException e) {
					LOG.log(Level.SEVERE, "Error while markdown "+text,e);
				}				
			}	
			else {
				String[] lines = text.split(System.getProperty("line.separator"));
				for(String line : lines) {
					line = line.trim();
					if(line.length() > 0) {
						line = escapeHtml(line);
//						line = includeALink(line);
//						line = includeAddressLink(line);
						line = "<p style=\"padding: 0;margin: 0;\">"+line+"</p>";
						sb.append(line);					
					}
				}			
			}
		}		
		return sb.toString();
	}
	public String formatCompactHtml() {
		StringBuffer sb = new StringBuffer();
		if(text != null) {
			try {
				String html = new Markdown4jProcessor().setDecorator(new ExtDecorator().useCompactStyle()).process(text);
				sb.append(html);
			} catch (IOException e) {
				LOG.log(Level.SEVERE, "Error while markdown "+text,e);
			}				
		}		
		return sb.toString();
	}
	private String escapeHtml(String s) {
//		"&amp;", "&quot;", "&lt;", "&gt;"
		s = s.replaceAll("&","&amp;");		
		s = s.replaceAll("<","&lt;");
		s = s.replaceAll(">","&gt;");
		return s;
	}
//	private String includeALink(String s) {
//		Pattern p = Pattern.compile("http://(\\S*)|https://(\\S*)");
//		Matcher m = p.matcher(s);
//		Map<String, String> replacements = new HashMap<String, String>();
//		while(m.find()) {
//		   String toReplace = m.group(0);
//		   String replaceBy = "<a href=\""+toReplace+"\" target=\"_new\">"+toReplace+"</a>";
//		   replacements.put(toReplace, replaceBy);
//		}
//		Iterator<String> it = replacements.keySet().iterator();
//		while(it.hasNext()) {
//			String toReplace = it.next();
//			 String replaceBy = replacements.get(toReplace);
//			s = s.replace(toReplace, replaceBy);
//		}
//		return s;
//	}
//	private String includeAddressLink(String s) {
//		Pattern p = Pattern.compile("<@(.*)@>");
//		Matcher m = p.matcher(s);
//		Map<String, String> replacements = new HashMap<String, String>();
//		while(m.find()) {
//			   String srcReplace = m.group(0);
//			   String toReplace = m.group(1);
//			   toReplace = toReplace.trim();
//			   String replaceBy = "<a href=\"https://maps.google.com/maps?q="+toReplace.replace(' ','+')+"\">"+toReplace+"</a>";
//			   replacements.put(srcReplace, replaceBy);
//		}
//		Iterator<String> it = replacements.keySet().iterator();
//		while(it.hasNext()) {
//			String toReplace = it.next();
//			 String replaceBy = replacements.get(toReplace);
//			s = s.replace(toReplace, replaceBy);
//		}
//		return s;
//	}
//	
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Integer getOrder() {
		return order;
	}

	public void setOrder(Integer order) {
		this.order = order;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getModificationDate() {
		return modificationDate;
	}

	public void setModificationDate(Date modificationDate) {
		this.modificationDate = modificationDate;
	}

	public Set<String> getTags() {
		return tags;
	}

	public void setTags(Set<String> tags) {
		this.tags = tags;
	}
	
	public String formatTags() {
		String s = "";
		for(String t : tags) {
			if(s.length() > 0) {
				s = s + " ";
			}
		  	s = s + t;
		}
		return s;
	}
	public void setTags(String tags) {
		if(tags != null) {
			this.tags = new LinkedHashSet<String>();
			String[] s = tags.split(" ");
			for(String ss : s) {
				if(ss.length() > 0) {
					this.tags.add(ss);
				}
			}
		}
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}
	public String formatColor(String color) {
		String catColor = null;
		
		if(category != null)
			catColor = category.getColor();
		
		if(color.equals(catColor)) {
			return "selected";
		}
		return "";
	}
	public String formatBgColor() {
		String color = null;
		
		if(category != null)
			  color = category.getColor();
		
		if(color != null && color.length() > 0) {
			return "style=\"background-color:"+color+";\"";
		}
		return "";
	}
	public String formatBorderColor() {
		String color = null;
		
		if(category != null)
			  color = category.getColor();

		if(color != null && color.length() > 0) {
			return "style=\"border-color:"+color+";\"";
		}
		return "";
	}
	public String formatSearch(String search) {
		
		String formatTitle = formatTitle();
		
		String stext = text.replaceAll("\\s", " ");
		
		int i = stext.indexOf(search);
		
		int begin = i - 50;
		
		if(begin < 0) begin = 0;
		
		int end = i + 50;
		if(end > stext.length()) end = stext.length();
		
		String fmtSearch = stext.substring(begin, end); 
		
		fmtSearch = fmtSearch.replace(search, "<span style=\"background-color:yellow;\">"+search+"</span>");
		
//		LOG.severe("formatSearch search "+search+" "+fmtSearch+" "+begin+" "+end+" "+i);
		
		return formatTitle + " [ "+fmtSearch+" ]";
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
}
