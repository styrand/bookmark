package org.kontxa.filter;

import java.io.IOException;
import java.security.Principal;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.kontxa.DataStoreService;
import org.kontxa.Options;
import org.kontxa.Service;

import com.google.appengine.api.users.UserService;
import com.google.appengine.api.users.UserServiceFactory;

public class AuthenticationFilter implements Filter {
	protected final Logger LOG = Logger.getLogger(this.getClass().getName());
	
	private final static String[] ACTIONS = { "edit", "delete", "truncate" , "options" , "restore" , "swap" , "trash" , "save"};
	
	@Override
	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest)req;		
		HttpServletResponse response = (HttpServletResponse)resp;
		
		try {
			
			Options options = getService().readOptions();
			String authMode = options.getAuthMode();
			
			Principal p = request.getUserPrincipal();
			
			LOG.info("AuthenticationFilter authMode "+authMode+", "+request.getUserPrincipal()+", "+request.getRemoteUser());
			
			//private mode : only admin user logged in can read and write (note, option, ...)
			if("private".equals(authMode)) {
		        UserService userService = UserServiceFactory.getUserService();        
		        String url = request.getRequestURI();
		        
		        LOG.info("AuthenticationFilter private mode "+url+" "+userService.createLoginURL(url)+" "+userService.createLogoutURL(url));

		        response.setContentType("text/html");
		        
		        //use not logged
		        if (request.getUserPrincipal() == null) {
		        	LOG.info("AuthenticationFilter private mode "+url+" 1 ...");
		        	response.sendRedirect(userService.createLoginURL(url));
	                return;						
		        } 
		        //user not logged
		        else if(!userService.isUserLoggedIn()/* || !userService.isUserAdmin()*/) {
		        	LOG.info("AuthenticationFilter private mode "+url+" 2 ...");
		        	response.sendRedirect(userService.createLoginURL(url));
	                return;						
		        }
		        //user logged as admin
		        else if(userService.isUserLoggedIn() && userService.isUserAdmin()) {
		        	LOG.info("AuthenticationFilter private mode "+url+" 3 ...");
		        	request.setAttribute("logoutURL", userService.createLogoutURL(url));
		        	chain.doFilter(request, response);
		        	return;
		        }			
		        //user logged but not admin
		        else {
		        	LOG.info("AuthenticationFilter private mode "+url+" 4 ...");
		            response.sendRedirect(userService.createLogoutURL(url));
	                return;						
		        }
			}
			else if("protected".equals(authMode)) {
		        UserService userService = UserServiceFactory.getUserService();        
		        String url = request.getRequestURI();
		        
		        LOG.info("AuthenticationFilter protected mode "+url+" ...");
		        
		        //check if user is logged as admin -> 
		        if(userService.isUserLoggedIn() && userService.isUserAdmin()) {
			        LOG.info("AuthenticationFilter protected mode "+url+" user loggedin as admin ...");
			        request.setAttribute("logoutURL", userService.createLogoutURL(url));
		        	chain.doFilter(req, resp);
		        	return;
		        }
		        //user not logged -> 
		        else if(!userService.isUserLoggedIn()) {
			        LOG.info("AuthenticationFilter protected mode "+url+" requestPath "+request.getServletPath()+" "+request.getUserPrincipal());
	        		String action = request.getServletPath().substring(1);
	        		//Action authorized
					if(Arrays.asList(ACTIONS).indexOf(action) == -1) {
				        LOG.info("AuthenticationFilter protected mode "+url+" action "+action+" authorized ...");
				        request.setAttribute("loginURL", userService.createLoginURL(url));
						chain.doFilter(request, response);
						return;
					}
					//Action forbidden
					else {
				        LOG.info("AuthenticationFilter protected mode "+url+" action "+action+" forbidden ...");
				        response.sendRedirect(userService.createLoginURL(url));
                        return;						
					}
		        }
		        //user logged but not admin
		        else {
			        LOG.info("AuthenticationFilter protected mode "+url+" requestPath "+request.getServletPath()+" "+request.getUserPrincipal());
	        		String action = request.getServletPath().substring(1);
	        		//Action authorized
					if(Arrays.asList(ACTIONS).indexOf(action) == -1) {
				        LOG.info("AuthenticationFilter protected mode "+url+" action "+action+" authorized ...");
				        request.setAttribute("logoutURL", userService.createLogoutURL(url));
						chain.doFilter(request, response);
						return;
					}
					//Action forbidden
					else {
				        LOG.info("AuthenticationFilter protected mode "+url+" action "+action+" forbidden ...");
				        response.sendRedirect(userService.createLogoutURL(url));
                        return;						
					}
//			        LOG.info("AuthenticationFilter protected mode "+url+" requestPath "+request.getServletPath()+" 2 ...");
//					//else if user not logged
//					if (request.getUserPrincipal() == null) {
//				        LOG.info("AuthenticationFilter protected mode "+url+" "+request.getServletPath()+" user principal null add login link ...");
//				        request.setAttribute("loginURL", userService.createLoginURL(url));
//			        	chain.doFilter(req, resp);
//			        	return;
//			        } 
//					else {
//						LOG.info("AuthenticationFilter protected mode "+url+" "+request.getServletPath()+" user principal not null...");
//						LOG.info("Principal "+request.getUserPrincipal().getName());
//					}
		        }
			}
			//public mode : everyone can read and write (notes, options, ...)
			else {
				chain.doFilter(request, response);
			}
//			chain.doFilter(req, resp);			
		}
		catch(Throwable e) {
			LOG.log(Level.SEVERE, "Error while filtering authentication "+request.getServletPath()+" "+request.getUserPrincipal(), e);
		}
	}

	@Override
	public void init(FilterConfig config) throws ServletException {
	}
	@Override
	public void destroy() {
	}
    public Service getService() {
    	return new DataStoreService();
    }


}
