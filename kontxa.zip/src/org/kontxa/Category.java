package org.kontxa;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Category implements Serializable, Order {
//  public static final Category UNCATEGORIZED = new Category(-1L, "");

  private Long id;
  
  private String title;
  
  private String color;
  
  private Integer order;
  
  private boolean open;
  
  private List<Note> notes = new ArrayList<Note>();
  
  public Category() {
	super();
  }
  public Category(Long id, String title, Integer order, boolean open) {
	  this.id = id;
	  this.title = title;
	  this.order = order;
	  this.open = open;
  }
  
  
public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public String getTitle() {
	return title;
}

public void setTitle(String title) {
	this.title = title;
}

public String getColor() {
	return color;
}

public void setColor(String color) {
	this.color = color;
}

public Integer getOrder() {
	return order;
}

public void setOrder(Integer order) {
	this.order = order;
}
public String formatColor(String color) {
	if(color.equals(this.color)) {
		return "selected";
	}
	return "";
}
public String formatBgColor() {
	if(color != null && color.length() > 0) {
		return "style=\"background-color:"+color+";\"";
	}
	return "";
}

public List<Note> getNotes() {
	return notes;
}

public void setNotes(List<Note> notes) {
	this.notes = notes;
}
public boolean getOpen() {
	return open;
}
public void setOpen(boolean open) {
	this.open = open;
}

}
