package org.kontxa;

import java.io.Serializable;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Set;

import com.google.appengine.api.users.UserService;
import com.google.appengine.api.users.UserServiceFactory;

public class Options implements Serializable {
	
	private Date modificationDate; 
	
	private String authMode;

	private String editor;
	
	private String rssMode;
	
	private Set<String> colors = new LinkedHashSet<String>();

	private Set<String> notesToCompose = new LinkedHashSet<String>();
	
	public Date getModificationDate() {
		return modificationDate;
	}

	public void setModificationDate(Date modificationDate) {
		this.modificationDate = modificationDate;
	}

	public Set<String> getColors() {
		return colors;
	}

	public String formatColors() {
		String s = "";
		for(String t : colors) {
			if(s.length() > 0) {
				s = s + " ";
			}
		  	s = s + t;
		}
		return s;
	}
	public void setColors(String colors) {
		if(colors != null) {
			this.colors = new LinkedHashSet<String>();
			String[] s = colors.split(" ");
			for(String ss : s) {
				if(ss.length() > 0) {
					this.colors.add(ss);
				}
			}
		}
	}

	public Set<String> getNotesToCompose() {
		return notesToCompose;
	}

	public void setNotesToCompose(Set<String> notesToCompose) {
		this.notesToCompose = notesToCompose;
	}
	
	public String formatSelectedNotes() {
		String s = "";
		for(String t : notesToCompose) {
			if(s.length() > 0) {
				s = s + "/";
			}
		  	s = s + t;
		}
		return s;
	}
	public String formatNotesToCompose() {
		String s = "";
		for(String t : notesToCompose) {
			if(s.length() > 0) {
				s = s + " ";
			}
		  	s = s + t;
		}
		return s;
	}
	public void setNotesToCompose(String notesToCompose) {
		if(notesToCompose != null) {
			this.notesToCompose = new LinkedHashSet<String>();
			String[] s = notesToCompose.split(" ");
			for(String ss : s) {
				if(ss.length() > 0) {
					this.notesToCompose.add(ss);
				}
			}
		}
	}

	public String getAuthMode() {
		return authMode;
	}

	public void setAuthMode(String authMode) {
		this.authMode = authMode;
	}
	/**
	 * User can write if : 
	 * - public authMode
	 * - private and user logged is admin
	 * @return
	 */
	public boolean canWrite() {
		UserService userService = UserServiceFactory.getUserService();
		if("private".equals(authMode) && userService.isUserLoggedIn() && userService.isUserAdmin()) {
			return true;
		}			
		else if("protected".equals(authMode) && userService.isUserLoggedIn() && userService.isUserAdmin()) {
			return true;
		}			
		else if("public".equals(authMode)) {
			return true;
		}
		return false;
	}
	public boolean isEditMode(String mode) {
		if("edit".equals(mode)) {
			return canWrite();
		}
		return false;
	}

	public String getRssMode() {
		return rssMode;
	}

	public void setRssMode(String rssMode) {
		this.rssMode = rssMode;
	}

	public String getEditor() {
		return editor;
	}

	public void setEditor(String editor) {
		this.editor = editor;
	}
	
}
