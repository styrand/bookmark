package org.kontxa;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartDocument;
import javax.xml.stream.events.StartElement;

public class NotesWriter {

	private List<Note> notes;

	public NotesWriter(List<Note> notes) {
		this.notes = notes;
	}
	
	private String formatDate(Date date) {
		return new SimpleDateFormat("dd/MM/yyyy").format(date);
	}

	public void write(OutputStream os) throws Exception {

		// Create a XMLOutputFactory
		XMLOutputFactory outputFactory = XMLOutputFactory.newInstance();

		// Create XMLEventWriter
		XMLEventWriter eventWriter = outputFactory
				.createXMLEventWriter(new OutputStreamWriter(os,"UTF-8"));

		// Create a EventFactory

		XMLEventFactory eventFactory = XMLEventFactory.newInstance();
//		XMLEvent end = eventFactory.createDTD("\n");

		// Create and write Start Tag

		StartDocument startDocument = eventFactory.createStartDocument();

		eventWriter.add(startDocument);

		// Create open tag
//		eventWriter.add(end);

		StartElement rssStart = eventFactory.createStartElement("", "", "notes");
		eventWriter.add(rssStart);
		eventWriter.add(eventFactory.createAttribute("date", formatDate(new Date())));

		// Write the different nodes

		for (Note note : notes) {
			eventWriter.add(eventFactory.createStartElement("", "", "note"));
			eventWriter.add(eventFactory.createAttribute("id", ""+note.getId()));
			if(note.getOrder() != null)
			eventWriter.add(eventFactory.createAttribute("order", note.getOrder().toString()));
			if(note.getCategoryId() != null)
			eventWriter.add(eventFactory.createAttribute("categoryId", ""+note.getCategoryId()));
			if(note.getModificationDate() != null)
			eventWriter.add(eventFactory.createAttribute("modificationDate", formatDate(note.getModificationDate())));
			if(note.getCreationDate() != null)
			eventWriter.add(eventFactory.createAttribute("creationDate", formatDate(note.getCreationDate())));
			if(note.getTags().size() > 0)
			eventWriter.add(eventFactory.createAttribute("tags", note.formatTags()));
			createNode(eventWriter, "text", note.getText(), true); 
			eventWriter.add(eventFactory.createEndElement("", "", "note"));
		}

		eventWriter.add(eventFactory.createEndElement("", "", "notes"));

		eventWriter.add(eventFactory.createEndDocument());

		eventWriter.close();
	}

//	private void createNode(XMLEventWriter eventWriter, String name,
//	String value) throws XMLStreamException {
//		createNode(eventWriter, name, value, false);
//	}
	private void createNode(XMLEventWriter eventWriter, String name,
	  String value, boolean cdata) throws XMLStreamException {
		XMLEventFactory eventFactory = XMLEventFactory.newInstance();
//		XMLEvent end = eventFactory.createDTD("\n");
//		XMLEvent tab = eventFactory.createDTD("\t");
		// Create Start node
		StartElement sElement = eventFactory.createStartElement("", "", name);
//		eventWriter.add(tab);
		eventWriter.add(sElement);
		if(cdata) {
			Characters characters = eventFactory.createCData(value);
			eventWriter.add(characters);			
		}
		else {
			// Create Content
			Characters characters = eventFactory.createCharacters(value);
			eventWriter.add(characters);			
		}
		// Create End node
		EndElement eElement = eventFactory.createEndElement("", "", name);
		eventWriter.add(eElement);
//		eventWriter.add(end);
	}
}