package org.kontxa;

import java.util.Comparator;

public class OrderComparator implements Comparator<Order> {

	@Override
	public int compare(Order o1, Order o2) {
		Integer i1 = o1.getOrder();
		Integer i2 = o2.getOrder();
		return i1.compareTo(i2);
	}

}
