package org.kontxa;

import java.util.List;

public interface Service {
  public Note createNote(String text, String type, Long categoryId);

  public Note update(Note note);

  public List<Note> list(List<String> ids);
  
  public List<Note> list();
  
  public List<Note> listByCategories(List<Long> categoryIds);
  
  public List<Category> listCategories();  

  public Category update(Category category);

  public Category getTrash();
  
  public Category readCategory(long id);
  
  public Category createCategory(String title, String color);  
  
  public Note read(long id);

  public Note delete(long id);

  public Note truncate(long id);

  public Note restore(long id);
  
  public void swap(long id1, long id2);
  
//  public List<Note> findByTags(String... tags);

  public List<Note> findByText(String... text);
  
  public void clean();
  
  public void reindex();
  
  public Options readOptions();

  public Options update(Options options);  
  
  
}
