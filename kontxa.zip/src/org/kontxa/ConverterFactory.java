package org.kontxa;

import java.util.Date;
import java.util.logging.Logger;

import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.Text;

public class ConverterFactory {
    protected final Logger LOG = Logger.getLogger(this.getClass().getName());
	
	public NoteConverter getNoteConverter() {
		return new NoteConverter();
	}

	public OptionsConverter getOptionsConverter() {
		return new OptionsConverter();
	}

	public CategoryConverter getCategoryConverter() {
		return new CategoryConverter();
	}
	
	private final class NoteConverter implements Converter<Note> {

		@Override
		public Note convert(Entity entity) {
			Note note = new Note();
			note.setCategoryId((Long) entity.getProperty("categoryId"));
			note.setType((String) entity.getProperty("type"));
			note.setCreationDate((Date) entity.getProperty("creationDate"));
			note.setModificationDate((Date) entity
					.getProperty("modificationDate"));
			note.setOrder(new Integer(entity.getProperty("order").toString()));
			note.setText(((Text) entity.getProperty("text")).getValue());
			note.setId(entity.getKey().getId());
			note.setTags((String) entity.getProperty("tags"));
			return note;
		}

		@Override
		public Entity convert(Note note) {
			LOG.info("createEntity note " + note.getId() + " " + note.getTags());
            Entity entity = null;
			if(note.getId() != null) {
				entity = new Entity(KeyFactory.createKey(Note.class.getSimpleName(), note.getId()));				
			}
			else {
				entity = new Entity(Note.class.getSimpleName());
			}
			Long catId = -1L;
			if(note.getCategoryId() != null) {
				catId = note.getCategoryId();
			}
			entity.setProperty("categoryId", catId);
			entity.setProperty("type", note.getType());
			entity.setUnindexedProperty("creationDate", note.getCreationDate());
			entity.setUnindexedProperty("modificationDate", note.getModificationDate());
			entity.setUnindexedProperty("order", note.getOrder());
			entity.setProperty("tags", note.formatTags());
			entity.setUnindexedProperty("text", new Text(note.getText()));
			return entity;
		}

		@Override
		public Class<Note> getTarget() {
			return Note.class;
		}

	}

	private final class OptionsConverter implements Converter<Options> {

		@Override
		public Options convert(Entity entity) {
			Options options = new Options();
			options.setAuthMode((String) entity.getProperty("authMode"));
			options.setEditor((String) entity.getProperty("editor"));
			options.setRssMode((String) entity.getProperty("rssMode"));
			options.setColors((String) entity.getProperty("colors"));
			options.setNotesToCompose((String) entity
					.getProperty("notesToCompose"));
			return options;
		}

		@Override
		public Entity convert(Options options) {
			Entity entity = new Entity(KeyFactory.createKey(Options.class.getSimpleName(), Options.class.getSimpleName()));
			entity.setUnindexedProperty("authMode", options.getAuthMode());
			entity.setUnindexedProperty("editor", options.getEditor());
			entity.setUnindexedProperty("rssMode", options.getRssMode());
			entity.setUnindexedProperty("colors", options.formatColors());
			entity.setUnindexedProperty("notesToCompose", options.formatNotesToCompose());
			return entity;
		}

		@Override
		public Class<Options> getTarget() {
			return Options.class;
		}
	}
	
	private final class CategoryConverter implements Converter<Category> {

		@Override
		public Category convert(Entity entity) {
			Category category = new Category();
			category.setId(entity.getKey().getId());
			category.setTitle(((Text) entity.getProperty("title")).getValue());
			category.setOrder(new Integer(entity.getProperty("order").toString()));
			category.setColor((String) entity.getProperty("color"));
			Boolean b = (Boolean) entity.getProperty("open");
			if(b != null) {
			  category.setOpen(b);				
			}
			return category;
		}

		@Override
		public Entity convert(Category category) {
			LOG.info("createEntity Category " + category.getId() + " " + category.getTitle());
            Entity entity = null;
			if(category.getId() != null) {
				entity = new Entity(KeyFactory.createKey(Category.class.getSimpleName(), category.getId()));				
			}
			else {
				entity = new Entity(Category.class.getSimpleName());
			}
			entity.setUnindexedProperty("color", category.getColor());
			entity.setUnindexedProperty("order", category.getOrder());
			entity.setUnindexedProperty("open", category.getOpen());
			entity.setUnindexedProperty("title", new Text(category.getTitle()));
			return entity;
		}

		@Override
		public Class<Category> getTarget() {
			return Category.class;
		}

	}
	
	  protected Key createKey(Class clazz, String id) {	  
		  Key key = KeyFactory.createKey(clazz.getSimpleName(), id);
		  return key;	  
	  }
	  protected Key createKey(Class clazz) {
		  return createKey(clazz, clazz.getSimpleName());	  
	  }

}
