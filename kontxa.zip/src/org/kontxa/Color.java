package org.kontxa;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.List;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class Color implements Serializable {
	private final static ResourceBundle bundle = ResourceBundle.getBundle("colors");
	
	private String code;
	
	private String label;
	
	public static List<Color> getColors() {
		List<Color> colors = new ArrayList<Color>();
		
		Enumeration<String> keys = bundle.getKeys();
		while(keys.hasMoreElements()) {
			String key = keys.nextElement();
			String value = bundle.getString(key);
			Color color = new Color();
			color.code = key;
			color.label = value;
			colors.add(color);
		}
		
		Collections.sort(colors, new ColorComparator());
		
		return colors;
	}
	
	public static String getLabel(String code) {
		String label = null;
		try {
			label = bundle.getString(code);			
		}
		catch(MissingResourceException e) {
			//DO NOTHING
		}
		if(label == null && code.startsWith("#")) {
			try {
				label = bundle.getString(code.substring(1));			
			}
			catch(MissingResourceException e) {
				//DO NOTHING
			}
		}
		if(label == null) {
			label = code;
		}
		return label;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	private static final class ColorComparator implements Comparator<Color> {

		@Override
		public int compare(Color o1, Color o2) {
			return new Integer(getPixel(o1.getCode())).compareTo(new Integer(getPixel(o2.getCode())));
		}
		
		private int getPixel(String code) {
			int hex = Integer.parseInt(code, 16);
		    int red = (hex & 0xFF0000) >> 16;
		    int green = (hex & 0xFF00) >> 8;
		    int blue = (hex & 0xFF);	
			  int pixel = (red & 0xFF) << 16 |
			            (blue & 0xFF) << 8 |
			            (green & 0xFF);			
			  
			  return pixel;
		}
		
	}
}
